# Design Principles and Invariants

This document enumerates the non‑negotiable principles that govern
every aspect of the Text OS.  These rules are binding; any
deviation requires a new Architecture Decision Record (ADR) that
explicitly overrides the relevant principle.

## AI bounds

- **AI is advisory, not authoritative.** The system must never
  accept AI‑generated content into canonical texts without an
  explicit apply step by the user.  AI suggestions are always
  presented separately from source text.
- **Evidence required.** All AI analyses and suggestions must link
  back to the source material that informed them, either by citing
  specific text fragments or recording retrieval context.
- **Model separation.** Tasks such as classification, rewriting,
  summarisation and thematic analysis must be routed to models
  appropriate for the task.  The primary LLM (e.g., GPT‑5.4) is used
  for deep understanding; lighter models handle simple routing to
  minimise cost.
- **Deterministic context assembly.** The inputs to any AI call
  must be explicitly enumerated; there is no implicit “magic
  memory”.  Retrieval functions must produce deterministic sets of
  text fragments based on defined queries and ranking rules.

## Data bounds

- **Immutability of raw text.** Original text entered or imported
  into the system is immutable.  Edits create new versions; the
  system never overwrites or deletes the original.
- **Explicit version control.** All derived texts (drafts, branches,
  rewrites) must record their provenance, diff from the prior
  version, and user intent.  Automatic merges are prohibited.
- **Portability first.** Texts are stored in human‑readable formats
  (e.g., Markdown) with metadata in a relational database.  Binary
  assets (audio, images) are stored separately with content hashes.
- **Separation of concerns.** Canonical texts live outside AI
  retrieval indexes.  Embedding stores and indexes are derived and
  can be rebuilt from canonical sources.

## UX bounds

- **Editor‑first experience.** The primary UI is a distraction‑free
  editor with optional panels for chat, outline and metadata.  The
  dashboard is secondary.
- **Chat as a tool, not the only interface.** Users should be able
  to perform operations (e.g., tag, move, rename) via UI controls
  without relying exclusively on chat commands.
- **Progressive disclosure.** Panels and controls appear when
  relevant; the interface avoids overwhelming users with all
  features at once.
- **Safety by default.** Actions that might irreversibly change
  canonical texts or metadata require confirmation.  Undo/redo must
  be available for reversible actions.

## Versions and apply rules

- **Apply is explicit.** Accepting an AI suggestion or user edit
  into a canonical draft must trigger a diff, record the change in
  the version history, and log the user’s intent.
- **Branches are cheap.** Users may create branches of drafts or
  books at any time.  Branching does not duplicate raw text; it
  references the same immutable text objects.
- **No silent merges.** Divergent branches must never be merged
  automatically.  A merge requires user selection of which diff
  segments to adopt.

## Additional invariants

- **Context transparency.** When the system provides a
  recommendation, it must display the context used (text fragments,
  outline nodes, style profiles) and allow the user to adjust the
  context before requesting a new suggestion.
- **Auditable AI.** Every AI call must be recorded with the
  timestamp, inputs, model used, outputs and cost.  Users must be
  able to review this log.
- **Single source of truth.** Canonical texts, metadata and
  decisions live in one authoritative database; caches and indexes
  derive from this source.
- **Extensibility.** Adding new text types, analysis modules or
  export formats should not require redesigning the core.
