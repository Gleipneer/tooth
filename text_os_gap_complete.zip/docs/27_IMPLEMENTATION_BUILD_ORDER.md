# Implementation Build Order

Building the Text OS requires careful sequencing to ensure that
foundational layers support higher‑level functionality.  This
document provides a recommended build order for developers and AI
agents implementing the system.  The order aligns with the
roadmap phases and emphasises determinism and testability.

## Principles

1. **Foundation first**: Establish the domain model, storage and
   basic CRUD operations before tackling UI or AI.
2. **Test‑driven**: Each module should include unit and integration
   tests.  Do not proceed to the next layer until tests pass.
3. **Minimal vertical slices**: Build end‑to‑end slices early (e.g.,
   import → store → view) to validate assumptions.
4. **Explicit interfaces**: Define API contracts and prompt schemas
   before implementation.  Avoid implicit coupling.

## Step‑by‑step order

1. **Project scaffolding**
   * Initialise repository with language tooling (e.g., Python and
     TypeScript/React project).
   * Set up build system, linters, formatter and test framework.
   * Create initial database migration for core tables (projects,
     raw_texts, drafts).

2. **Authentication and session management**
   * Implement local user login and session handling.
   * Seed initial admin user.

3. **File storage abstraction**
   * Create module for writing and reading text files to/from disk.
   * Handle atomic write and rollback on failure.

4. **CRUD APIs for Projects, RawTexts and Drafts**
   * Implement endpoints listed in `docs/17_BACKEND_API_CONTRACTS.md`.
   * Cover create, read, update metadata and archive operations.
   * Add basic validation and error handling.

5. **Import pipeline (plain text, Markdown)**
   * Build API to upload files and create import jobs.
   * Implement worker to parse and save raw texts.
   * Add job status tracking.
   * Write tests for import flows.

6. **Basic frontend shell**
   * Implement top bar, left rail and workspace layout.
   * Create project list and raw text list views.
   * Implement quick capture overlay.

7. **Editor with version control**
   * Integrate a structured editor (e.g., ProseMirror).
   * Enable editing raw texts (read‑only) and drafts (editable).
   * Implement auto‑save and version creation.
   * Add diff view and version history panel.

8. **Draft branching and freezing**
   * Allow creation of new drafts from parent drafts.
   * Implement freeze/unfreeze transitions.
   * Update UI to reflect draft status.

9. **Full‑text search**
   * Build search API and UI components.
   * Index raw texts and drafts in PostgreSQL FTS.
   * Implement search results panel with snippet highlighting.

10. **Book engine core**
    * Implement book CRUD APIs and outline node model.
    * Build outline editor UI with drag‑and‑drop.
    * Allow assignment of drafts to nodes.
    * Generate table of contents and export to Markdown.

11. **Chat workspace and AI orchestration**
    * Integrate AI provider SDK.
    * Build chat UI with context pinning.
    * Implement prompt assembly and structured output parsing.
    * Add suggestion cards and apply/ignore actions.
    * Record AI calls and suggestions in audit logs.

12. **Semantic search and embeddings**
    * Add embedding pipeline and vector index.
    * Implement API for semantic similarity search.
    * Enhance retrieval for AI context assembly.

13. **Cost tracking and budgets**
    * Implement cost accounting on AI calls.
    * Add user settings for monthly budgets and warnings.

14. **Observability and dashboards**
    * Instrument API and workers with metrics and traces.
    * Build simple dashboard showing job statuses and AI costs.

15. **Cleanup and polish**
    * Address edge cases and error handling.
    * Improve accessibility and keyboard shortcuts.
    * Write user documentation and update design docs.

Each step should result in a deployable incremental version.  If a
feature spans multiple steps, isolate its foundations first (e.g.,
define data models, then add UI).

## Acceptance gate per phase

After completing the steps in a phase, conduct a gate review:

* **Foundation gate (end of Step 6)**: Validate that core CRUD,
  storage and import work reliably.  Minimal UI is navigable.  All
  tests pass.
* **MVP gate (end of Step 12)**: Ensure that writers can ingest,
  organise, edit, chat with AI and build/export a book.  Obtain
  feedback from beta users.
* **Release gate (end of Step 15)**: All P0 features meet
  acceptance criteria, documentation is complete, observability is in
  place and cost tracking works.  Address outstanding risks or
  document them for later.

Skipping steps or merging phases risks undermining stability.  This
build order should be revisited as the team learns more, but any
changes must be justified in the decision log.