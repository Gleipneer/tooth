# Security, Privacy, Permissions and Audit

Ensuring the confidentiality and integrity of user data is critical
for the Text OS.  This document outlines the security model,
privacy posture, current single‑user assumptions and future
considerations for multi‑user permissions, as well as auditing
requirements.

## Security model

### Authentication

* **Local authentication**: Users authenticate to access the system
  using a username and password.  Passwords are hashed with a strong
  algorithm (e.g., Argon2).  Session tokens are stored securely
  (HTTP‑only cookies or bearer tokens).
* **Single user context**: MVP assumes one user per instance of the
  system.  User IDs are still implemented in the database to allow
  future multi‑user support.
* **Future multi‑user**: A permission model (see below) is defined
  for multi‑user scenarios but not enforced until P1/P2.

### Authorization and permissions

* In single‑user mode, the user has full read/write access to all
  objects.  Actions such as archiving or deleting can be executed.
* For future multi‑user mode, define roles:
  * **Owner**: full access to projects and data.
  * **Editor**: can edit drafts, assign texts, create books, but
    cannot delete raw texts.
  * **Reviewer**: can view texts and books, propose suggestions,
    cannot apply changes.
  * **Reader**: read‑only access to published books.
* Role assignments are stored per project in a `project_roles` table.
* Access control checks are enforced at the API layer; unauthorized
  actions return 403.

### Data encryption

* **At rest**: Use filesystem encryption (e.g., LUKS) or encrypt
  files at the application layer before writing.  Database columns
  containing sensitive information (e.g., API keys) are encrypted.
* **In transit**: Serve the web UI and API over HTTPS.  Use secure
  TLS configurations and rotate certificates periodically.

### Secrets management

* API keys and credentials for AI providers are stored in a secure
  secrets manager (e.g., environment variables managed by
  Kubernetes secrets).  They are not committed to version control.
* When calling provider APIs, use per‑user or per‑project keys if
  supported.

### Input sanitisation

* All user‑provided text is treated as untrusted.  When rendering
  in the UI, escape HTML to prevent XSS.
* When passing text to external providers, remove or redact
  personally identifiable information if the user enables privacy
  mode.

### Rate limiting and brute force protection

* Throttle login attempts and API usage to mitigate brute force
  attacks.
* Implement per‑IP or per‑user rate limits on expensive endpoints
  (e.g., AI calls) to control costs and abuse.

## Privacy posture

* **Data ownership**: Users own their content.  The system never
  shares or uses data for purposes other than providing the service.
* **Opt‑in telemetry**: If the application collects anonymous
  telemetry (e.g., usage statistics), it must be opt‑in.  No
  sensitive data is included.
* **Provider data sharing**: Content sent to AI providers may be
  used to improve models (depending on the provider’s policy).
  Inform users and allow them to opt out or choose providers with
  stricter data handling.
* **GDPR compliance**: Support data portability and deletion
  requests.  Retain logs for the minimum time required for
  troubleshooting and legal compliance.

## Audit

The system logs all critical actions:

* **AI interactions**: Each call records timestamp, user ID,
  provider, model, context references, prompt, output, cost and
  whether the suggestion was applied.  Logs are append‑only and
  tamper‑evident.
* **State changes**: Creation, update, archiving and deletion of
  objects (raw texts, drafts, books, outline nodes) with actor and
  previous vs. new state.  This includes apply/ignore decisions for
  suggestions.
* **Authentication events**: Logins, failed attempts, session
  expirations.
* **Job events**: Start, progress, completion and failure details.

Audit logs are stored in dedicated tables and can be exported for
compliance.  Access to logs is restricted to administrators.

## Future considerations

* **Fine‑grained row‑level security** in PostgreSQL for multi‑user
  instances.
* **End‑to‑end encryption** for especially sensitive texts.  The
  keys would be user controlled, limiting some functionality.
* **Two‑factor authentication** and integration with identity
  providers (e.g., OAuth) for enterprise deployments.
* **Data residency options** to store data within specific
  jurisdictions.

Security and privacy must be considered at every architectural
decision.  The system should make safe choices by default and give
users control over data and AI interactions.