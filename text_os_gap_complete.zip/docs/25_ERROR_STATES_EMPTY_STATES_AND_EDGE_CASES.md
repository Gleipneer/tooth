# Error States, Empty States and Edge Cases

Robust design anticipates and gracefully handles situations where data
is missing, operations fail, or user input is invalid.  This
document catalogues important error and empty states as well as
edge cases to consider when implementing the Text OS.

## General principles

* **Clear messaging**: Messages should tell the user what happened,
  why and how to recover.  Avoid technical jargon.
* **Non‑blocking**: Errors in one area should not crash the
  application.  Isolate failing components.
* **Retry/undo**: Where possible, provide options to retry or undo
  actions that failed.
* **Logging**: All errors should be logged with context for
  debugging.

## Empty states

Empty states are opportunities to guide the user:

| View | Condition | UI response |
| --- | --- | --- |
| Project list | No projects exist | Show message “You have no projects yet.  Create your first project.” with a prominent button. |
| Raw Text list | A project has no texts | Display “No raw texts found.  Use the quick capture or import to add your first piece.” |
| Draft list | No drafts exist | Suggest opening a raw text and starting a draft.  Provide an explanation of draft vs. raw text. |
| Book outline | No nodes defined | Show empty outline placeholder with “Add your first chapter” button.  Offer to apply a template. |
| Chat history | No messages yet | Explain what the chat can do and suggest a first prompt (e.g., “Analyse the current draft”). |
| Suggestions panel | No suggestions | Hide the panel or show “No AI suggestions at this time.” |

## Error states and handling

| Scenario | Cause | Handling |
| --- | --- | --- |
| Import job fails | Unsupported file, parsing error | Mark job as failed.  Show error summary.  Provide link to download error log and option to retry. |
| AI call exceeds context size | Too many tokens in context | Show error in chat: “Your request is too long.  Try reducing the selection or unpinning context.” |
| AI provider rate‑limited | API quota exceeded | Inform user that the request will be retried automatically.  Offer to upgrade plan or wait.  Log provider response. |
| Draft diff conflict | Suggestion does not apply cleanly | Mark suggestion as expired.  Ask user to refresh and re‑apply manually. |
| Permission denied (future) | User tries to modify resource without access | Display “You do not have permission to perform this action.” and hide editing controls. |
| Network offline | Connectivity lost | Enter offline mode.  Queue edits locally.  Notify user that changes will sync on reconnect. |
| Database down | Service unavailable | Display maintenance message.  Fail gracefully; do not attempt writes.  Show status page link. |
| Storage disk full | Cannot write files | Prevent further imports or edits.  Show critical error and instructions to free space or scale storage. |

## Edge cases

* **Large files**: Importing very large documents (>50 MB) may
  exhaust memory.  Use streaming parsers and chunk processing.
* **Non‑UTF8 encodings**: Detect and convert to UTF‑8.  If
  conversion fails, prompt user to provide correct encoding.
* **Self‑referencing drafts**: Prevent assigning a draft to an
  outline node in the same draft’s derivation chain.  This could
  create loops in the version graph.
* **Concurrent edits (future multi‑user)**: If two users edit the
  same draft simultaneously, detect conflict and require manual
  merge.
* **AI model changes**: When the provider updates models, output may
  change shape.  Validate outputs against expected schema and
  handle unknown fields gracefully.
* **Time zone differences**: Store timestamps in UTC.  Display
  converted times based on user’s locale.

Anticipating these states allows for defensive programming and a
smoother user experience.