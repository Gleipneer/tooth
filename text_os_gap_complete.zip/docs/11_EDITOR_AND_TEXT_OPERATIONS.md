# Editor and Text Operations

The editor is at the heart of the Text OS.  It must balance
flexibility, performance and safety.  This document outlines the
editor’s capabilities, the operations users can perform, and the
mechanisms that enforce the design principles of immutability and
explicit apply.

## Editor core

The editor is a rich‑text environment supporting **Markdown** as
the canonical formatting syntax.  Internally the editor uses a
structured document model (e.g., ProseMirror) to allow granular
operations and diff generation.  Key properties:

* **Single source of truth:** The editor loads a Draft or RawText
  into the structured model.  The canonical content remains on disk
  and in the diff store.  Edits are buffered until saved.
* **Live preview of Markdown:** Users see formatted text (headers,
  lists) as they type.  A raw Markdown view is available for
  advanced users.
* **Auto‑save with versioning:** The editor automatically saves
  changes at intervals, creating new draft versions.  Auto‑save
  never mutates existing versions.
* **Distraction‑free mode:** A fullscreen mode hides side panels and
  toolbars, allowing for focused writing.

## Text operations

### Basic formatting

* **Headings**: transform selected lines into `#`, `##`, etc.
* **Bold, italic, underline** via toolbar buttons or shortcuts.
* **Lists**: ordered and unordered lists; indent/outdent.
* **Block quotes** and **code blocks**.
* **Links**: inline link insertion; internal links to other drafts
  (future feature) or tags.

### Structural editing

* **Split paragraph** at cursor; join with preceding/next paragraph.
* **Move blocks** up or down via drag‑and‑drop or keyboard
  shortcuts.
* **Lock sections**: a user can lock a block or a range in a draft.
  Locked sections cannot be edited until unlocked; used to protect
  polished passages.
* **Comments**: select a range and add a comment.  Comments appear
  as side notes and support replies.  Comments persist across
  versions as long as the underlying text matches.
* **Track changes**: modifications are recorded as diff hunks
  compared to the parent version.  Users can view diff in a side
  panel and accept/reject each change.

### AI operations

* **Rewrite**: select text and choose rewrite type (shorten,
  expand, clarify, tone shift, rhythm polish).  The AI returns a
  diff; the editor shows a visual comparison and apply button.
* **Summarise**: for longer drafts, request a summary or outline.
  The AI returns a structured summary that can be inserted or
  attached as a comment.
* **Explain**: ask the AI to explain a passage (e.g., what does this
  metaphor suggest?).  Useful for self‑analysis or editing by an
  external editor.
* **Next line/paragraph suggestion**: request the AI to propose the
  next sentence or paragraph given the current context.  Requires
  explicit insertion by user.

### Version control

* **Branch**: create a new branch from the current draft.  The
  editor copies the diff chain and sets the branch name.  Users can
  switch branches via a dropdown.
* **Freeze**: mark the current draft as frozen; disables editing in
  this version.  The editor visually indicates frozen state.  To
  continue, create a new draft version.
* **Compare versions**: open two drafts side by side.  The editor
  highlights additions and deletions.  Users can copy changes from
  one side to the other.
* **Revert**: revert current draft to a previous version.  A revert
  creates a new version with the diff reversed.

### Safety features

* **Undo/redo**: unlimited undo/redo within the current editing
  session.  Undo does not cross version boundaries; to revert to a
  prior version, use the version control functions.
* **Save reminders**: unsaved changes are indicated.  When closing
  the editor or navigating away, the user is prompted to save or
  discard.
* **Conflict detection**: if another process (e.g., a script) has
  updated the underlying draft file, the editor warns the user and
  offers to reload or fork a new version.

## Integration with AI suggestions

Suggestions generated via chat or analysis may modify the draft.
The editor must integrate with the suggestion system:

1. **Receiving suggestion:** When a suggestion of type `rewrite` or
   `structure` targets the current draft, it appears in the right
   panel’s suggestion list.
2. **Preview:** Clicking a suggestion opens the diff view showing
   the proposed changes in context.
3. **Apply/ignore:** The user chooses.  Apply triggers creation of
   a new draft version, referencing the suggestion ID.  Ignore marks
   the suggestion as rejected.
4. **Anchoring:** Suggestions include anchor offsets.  If the draft
   has been edited since the suggestion was generated, the system
   must attempt to rebase the diff or mark the suggestion as
   expired.

## Offline editing considerations

The editor may eventually support offline mode.  In such cases:

* Edits are stored in local storage or a service worker queue.
* Upon reconnection, diffs are sent to the server to create new
  versions.  Conflict resolution rules apply.

## Future enhancements (P1/P2)

* **Custom macros and templates**: user‑defined snippets for
  repetitive structures (e.g., stanza patterns).
* **Read‑aloud**: integrated TTS for listening to drafts.
* **Corpus comparison**: highlight differences between current draft
  and style profile.
* **Non‑linear editing**: multiple active insertion points for
  experimental writing.

The editor’s design must remain adaptable without compromising the
core invariants of immutability, explicit apply and user control.