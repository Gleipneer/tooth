# Frontend App Shell and Navigation

This document describes the high‑level layout and navigation design
for the Text OS.  It focuses on the desktop web experience,
highlighting how users access core functions and move between
different modes (editing, chat, organisation).  Mobile adaptations
should follow similar principles with responsive adjustments.

## Overall layout

The app shell comprises four primary regions:

1. **Top bar** – global controls.
2. **Left rail** – project and object navigation.
3. **Main workspace** – editing and chat surfaces.
4. **Right panel** – contextual information and actions.

Below is a simplified representation:

```
┌─────────────────────────────────────────────────────────────────────────┐
│ Top Bar                                                               │
├───┬───────────────────────────────────────────┬───────────────────────┤
│   │                                           │                       │
│   │           Main Workspace                  │    Right Panel       │
│ L │                                           │                       │
│ e │                                           │                       │
│ f │                                           │                       │
│ t │                                           │                       │
│   │                                           │                       │
│ R │                                           │                       │
│ a │                                           │                       │
│ i │                                           │                       │
│ l │                                           │                       │
│   │                                           │                       │
└───┴───────────────────────────────────────────┴───────────────────────┘
```

### Top bar

The top bar contains:

* **Project selector** – A dropdown or breadcrumb showing the
  current project with quick switch capability.
* **Global search** – A search box or icon to open search across
  all projects (full‑text and semantic).
* **Notifications** – Access to job status, alerts (e.g., import
  completed), and AI cost usage.
* **Settings/profile** – User settings, style profiles, cost
  budgets, and sign‑out.
* **Help** – Access to documentation and keyboard shortcuts.

### Left rail

The left rail is the primary navigator.  It displays a collapsible
tree structure:

* **Projects root** – List of all projects the user owns.
* Within each project:
  * **Books** – Expandable list of book projects.
  * **Raw Texts** – List of raw texts; optionally grouped by date.
  * **Drafts** – List of drafts; can be filtered by status or
    branch.
  * **Collections** – User‑defined groupings.
  * **Conversations** – Chat threads.
  * **Tags/Themes** – Manage tags and view items by tag/theme.

The rail should allow drag‑and‑drop (e.g., dragging a draft into a
book node) and right‑click context menus for quick actions (rename,
archive).

### Main workspace

The central area is used for the primary activity selected in the
left rail:

* **Editor mode** – When a RawText or Draft is selected, the
  workspace displays the editor.  Features include Markdown
  formatting tools, diff view, comment threads, and an indicator of
  version state (`in_progress`, `frozen`, `archived`).
* **Book mode** – When a Book is selected, the workspace shows an
  outline editor (tree of nodes) with drag‑and‑drop reordering and
  assignment capabilities.  Selecting a node can open its assigned
  draft(s) in a split view.
* **Chat mode** – When a Conversation is selected, the workspace
  displays a chat interface reminiscent of ChatGPT.  Messages are
  grouped by role; AI responses use cards with actions (apply,
  ignore, copy).  The user can pin context objects to the chat.
* **Collection or tag mode** – Listing of texts matching the
  collection or tag; selecting an item opens the editor or book.

The main workspace should support split views, such as editing a
draft while chatting about it or viewing an outline alongside the
assigned text.  Split views improve multitasking but must be
optional to preserve a focused writing experience.

### Right panel

The right panel surfaces contextual information and quick actions
related to the current selection:

* **Details** – Metadata about the selected text/draft/book (e.g.,
  language, tags, themes, length, creation date, branch).  Editable
  fields are clearly marked.
* **Outline** – For drafts, show the book outline path if the
  draft is mapped to a chapter; for books, show the outline tree.
* **AI suggestions** – A list of pending suggestions and their
  status (open, applied, ignored).  Clicking a suggestion opens
  preview and apply controls.
* **Relations** – Links to related texts (e.g., other drafts of
  same raw text, texts sharing tags or themes).  Provides quick
  navigation and inspiration.

The right panel is collapsible and appears when context is
significant; it remains hidden to keep the workspace uncluttered.

## Mobile considerations

On mobile devices, the layout should adapt:

* The left rail becomes a slide‑out drawer.  Navigation occurs via
  a hamburger menu.
* The right panel becomes an overlay accessible via a “Details”
  button.
* The top bar condenses into a small header with a project selector
  and search icon.
* Editing remains full‑screen with toolbars hidden behind
  collapsible menus.

## Navigation principles

* **Consistency:** The same actions (e.g., archive, tag) appear in
  context menus regardless of where they are invoked.
* **Visible context:** Breadcrumbs and icons reflect the current
  context (project, book, draft).  Pinned contexts in chat clearly
  show which texts are influencing the AI.
* **Keyboard shortcuts:** Writers often prefer keyboard navigation.
  Common actions (save, new draft, apply suggestion) should be
  accessible via shortcuts.
* **Accessible design:** Colour contrast, text sizing and focus
  indicators must meet accessibility standards.

This app shell and navigation model should be validated through
prototyping and usability tests.  It is designed to balance the
needs of deep focus writing with complex organisation and AI
assistance.