# Ubuntu Deployment and Operations

This document defines the **canonical deployment target** for Text OS:
a self-hosted deployment on an Ubuntu server. It is intentionally
operational and implementation-oriented. It supplements the product and
architecture documents by specifying how the system is expected to run
in production.

## Locked decisions

- **Host OS:** Ubuntu Server LTS on x86_64.
- **Primary topology:** single-node deployment for MVP; split services on
  the same host.
- **Reverse proxy:** Nginx.
- **App runtime:** Python backend exposed through ASGI and managed by
  `systemd`.
- **Frontend delivery:** static React build served by Nginx.
- **Database:** PostgreSQL with `pgvector` enabled on the same server for
  MVP.
- **Queue / broker / cache:** Redis-compatible service (Redis or Valkey)
  on the same server for MVP.
- **Background execution:** dedicated worker service plus dedicated
  scheduler service.
- **Persistent text storage:** local filesystem under `/srv/textos/`
  mounted on durable storage.
- **Backups:** database dump + filesystem snapshot + off-host encrypted
  copy.
- **Process supervision:** `systemd`, not ad hoc shell sessions.
- **Secrets:** environment file readable only by the service account;
  never committed to the repo.

## Assumptions

- MVP targets a single writer or a very small private deployment.
- Moderate traffic is expected; not internet-scale multi-tenant traffic.
- Public internet exposure is optional. If exposed publicly, TLS is
  mandatory. If private-only, deployment behind Tailscale or a VPN is
  acceptable.

## Canonical directory layout

```text
/opt/textos/
  releases/
    2026-04-20T120000Z/
      backend/
      frontend/
      migrations/
  current -> /opt/textos/releases/<active-release>

/srv/textos/
  raw/
  drafts/
  exports/
  imports/
  attachments/
  backups/
  logs/

/etc/textos/
  textos.env
  nginx/
  backup/
```

### Rationale

- `/opt/textos/` stores release artifacts and supports rollback by
  symlink switch.
- `/srv/textos/` stores mutable production data and generated files.
- `/etc/textos/` stores host-local configuration and secrets references.

## Canonical services

The MVP production host runs these services:

| Service | Responsibility | Canonical process owner |
| --- | --- | --- |
| `nginx` | TLS termination, static frontend, reverse proxy to API | system package |
| `textos-api` | FastAPI/ASGI application | `systemd` unit |
| `textos-worker` | async jobs: import, export, embeddings, analysis | `systemd` unit |
| `textos-scheduler` | recurring jobs: backups, refresh, resurfacing later | `systemd` unit |
| `postgresql` | primary source of truth for metadata and relations | system package |
| `redis` / `valkey` | queue broker, lightweight cache, rate limiting | system package |
| `fail2ban` | SSH / public endpoint hardening | system package |
| `ufw` | host firewall | system package |

## Service user model

Create a dedicated non-login service account:

```text
user: textos
group: textos
shell: /usr/sbin/nologin
home: /opt/textos
```

Rules:

- API, worker and scheduler run as `textos`.
- Files under `/srv/textos/` are owned by `textos:textos`.
- Database credentials are stored in `/etc/textos/textos.env` with mode
  `0600`.
- Nginx may read the frontend build but not application secrets.

## Network and port model

Canonical public/private ports:

| Port | Scope | Purpose |
| --- | --- | --- |
| 22 | restricted | SSH admin access |
| 80 | public/private | HTTP redirect to HTTPS if public |
| 443 | public/private | HTTPS frontend + API |
| 5432 | local only | PostgreSQL |
| 6379 | local only | Redis / Valkey |
| 8000 | local only | ASGI upstream |
| 9000+ | local only | optional internal admin metrics endpoints |

Rules:

- PostgreSQL and Redis must **not** be publicly exposed.
- SSH should be restricted by IP allowlist, VPN, or both.
- If the host is internet-facing, enable rate limiting and bot/noise
  suppression at Nginx.

## Nginx responsibilities

Nginx owns:

- TLS termination.
- static serving of the React build.
- proxying `/api/` and websocket endpoints to the ASGI service.
- gzip/brotli where appropriate.
- upload size limits.
- request body timeout and proxy timeout policy.
- request logging to a dedicated access log.

Canonical routing:

- `/` -> frontend static app.
- `/assets/*` -> immutable hashed static assets.
- `/api/*` -> upstream ASGI app.
- `/healthz` -> lightweight health endpoint.
- `/metrics` -> optional internal-only endpoint or blocked externally.

## Backend process model

Canonical API startup pattern:

- ASGI app served by Uvicorn worker processes.
- `systemd` handles restart policy, logs and environment.
- frontend never talks directly to Python on a public port.

Recommended `systemd` characteristics:

- `Restart=always`
- bounded shutdown timeout
- explicit working directory
- explicit environment file
- journald logging
- hardening flags where practical:
  - `NoNewPrivileges=true`
  - `PrivateTmp=true`
  - `ProtectSystem=full`
  - `ProtectHome=true`

## Background jobs

Canonical split:

- **API service** handles synchronous HTTP requests only.
- **Worker service** handles:
  - import parsing
  - OCR/transcription orchestration
  - embedding generation
  - semantic index refresh
  - export rendering
  - large analysis jobs
- **Scheduler service** handles:
  - periodic cleanup
  - backup launch
  - nightly index validation
  - cost report rollups
  - future resurfacing jobs

This separation is mandatory. The API must not perform heavy book export
or archive-wide analysis inline.

## PostgreSQL posture

Canonical MVP posture:

- local PostgreSQL instance on the Ubuntu host
- dedicated DB and dedicated DB user
- WAL enabled
- regular vacuum/analyze
- `pgvector` extension enabled
- database access limited to localhost

Minimum schema governance rules:

- migrations are versioned and run during deployment
- destructive migrations require explicit backup checkpoint
- no manual schema edits in production

## Redis / Valkey posture

Use Redis-compatible infrastructure for:

- queue broker
- transient locks
- rate limiting counters
- lightweight result caching

Rules:

- localhost only
- persistence enabled for queue resilience where appropriate
- no canonical text data stored in Redis
- safe to flush cache, unsafe to drop queue without operational intent

## Filesystem storage posture

Canonical paths under `/srv/textos/`:

| Path | Contents | Durability |
| --- | --- | --- |
| `raw/` | immutable raw Markdown sources | critical |
| `drafts/` | versioned draft bodies | critical |
| `exports/` | generated export artifacts | medium |
| `imports/` | original uploaded files where retained | medium |
| `attachments/` | audio/image files | critical if retention enabled |
| `backups/` | local backup staging | medium |
| `logs/` | optional app-level structured logs | low/medium |

Rules:

- raw texts are append-only from an operational standpoint.
- draft versions are never silently replaced.
- exports may be garbage-collected after a retention period.
- attachments may be deleted only according to user-visible retention
  policy.

## Backup strategy

Canonical backup layers:

1. **Database logical backup**  
   nightly `pg_dump` for schema + data.
2. **Filesystem backup**  
   snapshot or archive of `/srv/textos/raw`, `/srv/textos/drafts`,
   `/srv/textos/attachments`, and export metadata where needed.
3. **Off-host encrypted copy**  
   push backups to external storage (S3-compatible bucket, rsync target,
   or encrypted remote host).

Minimum retention recommendation:

- daily backups: 14 days
- weekly backups: 8 weeks
- monthly backups: 12 months

Minimum restore drills:

- restore database to staging
- restore text files to staging
- verify a sampled set of raw texts, drafts, books and exports
- document restore duration and failures

## Deployment workflow

Canonical release flow:

1. build backend artifact
2. build frontend artifact
3. stage release into `/opt/textos/releases/<timestamp>/`
4. run database migration against a verified backup checkpoint
5. switch `/opt/textos/current` symlink
6. restart `textos-api`, `textos-worker`, `textos-scheduler`
7. run smoke checks:
   - health endpoint
   - login
   - open project
   - load draft
   - send chat request
   - queue import job
   - export small book
8. if smoke checks fail, roll back symlink and restart services

## Rollback policy

Rollback is mandatory and must be simple.

- frontend/backend rollback: switch the `current` symlink to prior
  release and restart services.
- database rollback: restore from backup only if migration is not
  backward compatible and failure is severe.
- if migrations are additive and backward compatible, prefer app
  rollback without DB restore.

## TLS and exposure models

### Public deployment

Use:

- Nginx + Let's Encrypt / Certbot
- HTTPS only
- HSTS after validation
- CSRF protection and secure cookies
- `SameSite=Lax` or stricter where feasible

### Private deployment

Acceptable options:

- Tailscale-only access
- reverse proxy behind a private network gateway
- no public DNS required

Even in private mode, use HTTPS where practical.

## Monitoring and observability on Ubuntu

Minimum operational stack:

- journald for service logs
- Nginx access/error logs
- PostgreSQL logs
- basic metrics endpoint from app
- disk free monitoring
- memory and CPU monitoring
- alert on:
  - API down
  - worker down
  - scheduler down
  - backup failure
  - disk usage > 80%
  - database connection failures
  - AI provider error spike
  - queue backlog beyond threshold

Optional but recommended:

- Prometheus
- Grafana
- Loki / Promtail

## Security hardening checklist

- disable password auth for SSH where possible; prefer keys
- restrict SSH with firewall and/or VPN
- enable unattended security updates on Ubuntu
- use `ufw` deny-by-default inbound policy
- fail2ban on SSH and optionally Nginx auth endpoints
- rotate secrets on compromise or personnel change
- keep Python dependencies pinned and scanned
- never expose `.env` or debug endpoints
- disable debug mode in all environments beyond local dev

## Capacity assumptions for MVP

Canonical single-host planning target:

- 2–4 vCPU
- 8–16 GB RAM
- SSD-backed storage
- enough disk for text archive growth + exports + backups

Scale-out triggers:

- queue backlog grows persistently
- embedding jobs interfere with user-facing latency
- database CPU saturation
- export rendering causes API starvation

First scale steps:

1. move worker to separate host
2. move PostgreSQL to managed or dedicated host
3. move attachments/exports to object storage
4. add read replicas only if real query load justifies it

## Risks / trade-offs

- single-host MVP is operationally simple but creates blast radius if the
  host fails.
- colocating PostgreSQL and vector search is efficient for MVP but may
  require separation later.
- Nginx + systemd is operationally robust on Ubuntu, but deployment
  discipline matters more than tooling choice.
- local filesystem storage preserves portability, but backups become
  non-negotiable.

## Open questions

- whether the first production deployment should be public HTTPS or
  private VPN-only
- whether OCR/transcription should run on the same host or a separate
  worker with tighter quotas
- whether exports should be retained indefinitely or pruned

## Minimum operational acceptance gate

A deployment is not considered production-ready until it can demonstrate:

- successful cold start after host reboot
- successful backup and restore drill
- successful small import, chat request and export
- successful rollback to prior release
- successful log inspection and alert test
- no public exposure of database, queue or debug endpoints
