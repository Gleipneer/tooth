# Roadmap, Phases and Release Plan

This roadmap lays out the sequence of work for delivering the Text OS
from MVP to a mature platform.  It aligns with the scope document
and prioritises building a stable foundation before adding advanced
features.

## Phase 0: Foundations (Setup)

* Define domain model and database schema (see docs/07 and docs/18).
* Set up repository structure and CI/CD pipeline.
* Implement authentication and single‑user management.
* Build basic CRUD API for projects, raw texts and drafts.
* Set up file storage and import pipeline for plain text and
  Markdown.
* Implement basic full‑text search.
* Create core UI shell (top bar, left rail, workspace).
* Build the editor with Markdown support and versioning.
* Deliver quick capture overlay.
* Configure AI provider integration; create orchestration layer
  skeleton.
* Implement logging, metrics, and audit tables.

**Deliverable:** internal alpha with capture, storage and basic
editing.

## Phase 1: MVP Release

Focus on the features classified as P0:

* Expand API to include drafts diff application and branching.
* Build chat workspace with context pinning and AI suggestions for
  rewriting and analysis.
* Develop basic book engine: create book, define outline,
  assign drafts, generate table of contents and export to Markdown.
* Add semantic search within projects using embeddings.
* Implement suggestion application and ignore flow.
* Add basic cost tracking and warnings.
* Complete import review queue and deduplication.
* Improve editor with diff view, comments and lock sections.
* Finalise MVP UI and polish error/empty states.
* Conduct user testing and feedback rounds.

**Deliverable:** public beta.  Single user can manage a corpus,
build books and use AI assistance.

## Phase 2: Post‑MVP Enhancements

After MVP stabilises, prioritise P1 features:

* Support additional import formats (docx, pdf, epub) and media
  ingestion (audio, images).
* Introduce style profiles and theme analysis.
* Build hybrid search across entire archive with advanced filters.
* Allow user‑defined prompts and reusable recipes.
* Add EPUB/PDF export with default styles; support covers.
* Implement cost dashboards and budgets per project.
* Lay groundwork for multi‑user mode: design permission model,
  partition data; start with read‑only sharing.
* Enhance observability dashboard with AI evaluation metrics.
* Add advanced book templates and outline variants.
* Expand job system with analysis pipelines (e.g., motif clustering).

**Deliverable:** stable release 1.0.  The system covers most
writers’ needs and demonstrates AI‑powered organisation and book
construction.

## Phase 3: Future and Experimental Features

P2 features depend on user demand and technical feasibility:

* Timeline and motif graphs; visual analytics on the corpus.
* Daily resurfacing engine and return suggestions.
* Corpus‑aware style imitation and personalised fine‑tuning.
* Conflict‑safe collaborative editing with real‑time sync.
* Offline‑tolerant client with local cache and sync engine.
* Web clipper and email ingestion.  Build browser extension.
* Multi‑provider abstraction and pluggable local models.
* Moderation and misuse detection to guard against harmful use of AI.
* Enhanced privacy features (e2e encryption, data residency).

These extensions will be subject to ADRs and may require major
design changes.  They should not compromise the stability of the
core system.

## Release planning and risk management

* **Incremental delivery**: Each phase should be broken into
  milestones (~4–6 weeks).  Deliver working increments that users
  can test and provide feedback on.
* **Risk‑driven sequencing**: Implement high‑risk components early
  (e.g., AI orchestration, book engine) to validate assumptions.
* **Feature toggles**: Use configuration flags to enable/disable
  incomplete or experimental features.  This facilitates gradual
  rollout and A/B testing.
* **Documentation and training**: Each release must include
  updated documentation and, if appropriate, onboarding materials.

By following this roadmap, the project can deliver value quickly
while managing complexity and uncertainty.