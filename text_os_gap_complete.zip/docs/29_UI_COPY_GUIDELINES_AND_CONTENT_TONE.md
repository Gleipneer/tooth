# UI Copy Guidelines and Content Tone

This document defines the tone and style for user‑facing text in the
Text OS.  Consistent copy enhances usability, builds trust and
reflects the product’s values.  It also delineates the voices of
system messages vs. AI responses.

## General tone

* **Clear and concise**: Write in simple, straightforward language.
  Avoid jargon and ambiguous abbreviations.
* **Neutral and professional**: Maintain a calm, respectful tone.
  Do not sound overly casual or too corporate.
* **Guiding, not commanding**: Offer suggestions and guidance rather
  than directives.  Use verbs like “You can…” instead of “You must…”.
* **Empathetic**: Acknowledge user feelings when errors occur.  Use
  phrases like “We’re sorry” when appropriate.
* **Svensk/English duality**: The primary UI language is English,
  but certain examples or user texts may be in Swedish.  Support
  Swedish labels where appropriate and ensure translations are
  accurate.

## Voice distinction

The Text OS has two primary voices: **System** and **Assistant**.

### System voice

* Used for UI labels, buttons, error messages and confirmations.
* Speaks in the first person plural (“We have saved your draft.”)
  when appropriate, or in the imperative for button labels (“Save”).
* Does not pretend to be human.  It represents the application.
* Example error copy (Swedish first, then English):

  > **Svenska:** “Det uppstod ett fel vid importen.  Försök igen eller
  > kontakta support om problemet kvarstår.”
  >
  > **English:** “An error occurred during import.  Please try again or
  > contact support if the problem persists.”

* Example empty state: “No drafts found.  Create your first draft to
  start writing.”  In Swedish: “Inga utkast hittades.  Skapa ditt
  första utkast för att börja skriva.”

### Assistant voice

* Represents the AI assistant.  It should be helpful, factual and
  transparent about uncertainties.
* When providing suggestions, use hedging language (“You might
  consider…”, “Here are some options…”).  Avoid absolute
  statements.
* If the assistant is unsure, it must say so (“I’m not certain
  because the provided context is limited.”).
* It must cite sources or evidence when referring to specific text
  fragments.  Use IDs (e.g., “In draft 3, section 2…”).
* The assistant must never promise actions outside its scope (e.g.,
  “I will publish your book”).  It should instead propose and ask
  for confirmation.

## Error messages

* Describe the problem in plain language and, where possible,
  include the cause.  Example: “Cannot apply suggestion because the
  draft has changed.  Please refresh and try again.”
* Provide a recovery path (“Try again”, “Reload”, “Contact
  support”).
* Avoid blame.  Use passive constructions if the cause is external.
* Do not expose internal error codes or stack traces to the user.

## Action labels

* Use verbs that describe the action clearly: “Save”, “Discard”,
  “Export”, “Apply”, “Ignore”.
* For destructive actions, use a warning colour and confirm via
  dialog (“Are you sure you want to archive this book?”).
* Keep labels short; avoid ellipses unless the action opens a new
  dialog or requires further input.

## Empty and loading states

* Encourage users to take the next step.  E.g., “You haven’t added
  any tags yet.  Use the ‘Add Tag’ button to organise your texts.”
* Use skeleton loaders or spinners for loading states and combine
  with brief explanations (“Loading drafts…”).  Avoid leaving a
  blank screen.

## System vs. user prompts in chat

* System messages (e.g., system prompts to the AI) are hidden from
  the user.  They should be succinct and factual.  The user sees
  assistant replies only.
* If a user input is ambiguous, the assistant should ask clarifying
  questions before acting.
* The assistant should not use emojis or internet slang.  It may
  use italics or bold to highlight key terms but sparingly.

## Translation and localisation

* All system copy must be internationalised.  Use translation keys
  and resource files.  Keep sentences concise to facilitate
  translation.
* Provide a mechanism to toggle language (English, Swedish) in the
  UI.  Ensure date/time formats and pluralisation rules are locale
  aware.

## Reviewing copy

* Copy should be reviewed by native speakers of the target
  languages and by product owners to ensure consistency with brand
  values.
* Changes to tone or style guidelines must be documented and
  communicated to all contributors.

By following these guidelines, the Text OS maintains a coherent,
friendly and trustworthy interface that supports both Swedish and
English writers.