# Runtime, Cost and Capacity Guardrails

This document turns the cost and model-routing policy into concrete
runtime guardrails. It exists because architecture-level intent is not
enough: the running system needs thresholds, defaults and escalation
rules.

## Locked decisions

- The product defaults to **cost-aware mode**, not unconstrained model
  usage.
- Expensive operations require either:
  - a low estimated cost, or
  - explicit user confirmation.
- Heavy archive-wide AI jobs run asynchronously.
- Context size is bounded per task type.
- The system prefers **graceful downgrade** over silent failure.

## Budget model

Budgets are tracked at three levels:

1. **per request**
2. **per project / book session**
3. **per calendar month**

### Default single-user budget profile

| Budget scope | Default |
| --- | --- |
| soft warning threshold | USD 10 / month |
| strong warning threshold | USD 20 / month |
| hard stop threshold | USD 30 / month |
| per-request auto-run ceiling | USD 0.25 estimated |
| per-request confirmation threshold | USD 0.25–0.75 estimated |
| per-request hard block threshold | > USD 0.75 unless explicit override |

These are product defaults, not provider facts. They may be changed by
the user or operator.

## Cost behavior by threshold

### Under soft warning threshold

- all configured features available
- normal routing rules apply

### At or above soft warning threshold

- visible budget badge in topbar
- large archive-wide AI jobs require explicit confirmation
- recommend lower-cost mode where applicable

### At or above strong warning threshold

- default model for non-critical tasks downgrades one tier
- archive-wide analyses and large exports prompt before running
- batch operations are chunked more aggressively

### At hard stop threshold

- no new heavy model calls without explicit user override
- cheap classification and local-only operations still allowed
- user is shown:
  - current spend
  - blocked operations
  - override action if enabled by policy

## Task routing matrix

| Task | Default model class | Max context class | Notes |
| --- | --- | --- | --- |
| language detection | cheap classifier | tiny | no heavy model |
| text-type detection | cheap classifier | tiny | no heavy model |
| tag/theme suggestion (small) | mini model | small | degrade early if budget tight |
| rewrite selected paragraph | premium model | medium | high value, user-facing |
| rewrite whole draft | premium model | large | async if over threshold |
| structure analysis for one chapter | premium model | large | sync if manageable |
| full-book structure analysis | premium model | very large | async only |
| archive-wide motif clustering | batch/async pipeline | huge | never inline |
| next-step suggestion for current draft | mini or premium depending context | medium | prefer cheaper unless complexity high |
| semantic embeddings | embedding model | chunked | background only |

## Context-size guardrails

The system must not assemble unbounded prompts.

### Hard limits by operation

| Operation | Maximum assembled text objects | Maximum retrieved fragments | Delivery mode |
| --- | --- | --- | --- |
| rewrite selection | 1 active object + style profile | 0–3 | sync |
| analyze current draft | 1 draft + parent raw text | 3–8 | sync |
| compare two drafts | 2 drafts only | 0–4 | sync |
| chapter structure analysis | 1 outline node + assigned texts | 4–10 | sync |
| full-book analysis | whole outline + sampled nodes | 10–25 | async |
| project theme scan | project-wide sampled corpus | 20–50 | async only |

### Trimming rules

When context exceeds limit, trim in this order:

1. remove non-essential retrieved fragments
2. compress older conversation turns
3. remove optional style/reference objects
4. ask user to narrow the request

Do **not** silently drop the primary selected object.

## Concurrency guardrails

Canonical single-host Ubuntu defaults:

| Work type | Max concurrency |
| --- | --- |
| API premium AI calls | 2 in-flight |
| API cheap AI calls | 6 in-flight |
| embedding workers | 2 jobs |
| export workers | 1 heavy job at a time |
| OCR/transcription workers | 1–2 jobs |
| archive-wide analysis jobs | 1 at a time |

Rationale:

- preserve interactive responsiveness
- prevent worker starvation
- protect host memory
- avoid runaway provider spend

## Synchronous vs asynchronous policy

### Must remain synchronous

- small rewrite requests
- small analysis requests on a single draft
- next-step suggestions for current draft
- compare-two-text requests within bounded context

### Must become asynchronous

- full-book structural analysis above configured size
- project-wide motif clustering
- bulk imports with parsing
- export to complex formats
- OCR/transcription
- large re-embedding jobs

If the system estimates an operation will exceed synchronous time budget,
it must convert it to a job and tell the user.

## Time budget targets

| Operation class | Target UX time budget |
| --- | --- |
| tiny local action | < 150 ms |
| normal API action | < 500 ms |
| small AI response first token | < 3 s ideal |
| small AI full response | < 10 s target |
| heavy sync AI operation | < 20 s absolute ceiling |
| async job handoff | immediate job creation + progress UI |

If expected duration exceeds the heavy sync ceiling, queue the task.

## Fallback matrix

### Provider failure

1. retry transient failure up to configured retry count
2. route to fallback model/provider if policy allows
3. downgrade capability if needed
4. if still failing, preserve prompt and offer retry later

### Budget pressure

1. downgrade premium analysis to mini where acceptable
2. reduce retrieved context count
3. queue for later instead of executing now
4. request explicit user confirmation

### Host pressure

If CPU, memory or queue backlog exceed thresholds:

- throttle archive-wide jobs
- pause non-essential embeddings
- preserve interactive rewrite/chat actions
- surface degraded mode banner to user

## Host pressure thresholds

Single-host defaults:

| Metric | Warning | Protective action |
| --- | --- | --- |
| CPU sustained | > 75% for 5 min | reduce worker concurrency |
| Memory sustained | > 80% for 5 min | pause heavy jobs, limit exports |
| Disk free | < 20% | warn operator, pause large imports |
| Queue backlog | > 100 pending heavy jobs | stop accepting new heavy jobs |
| DB connections | > 80% of pool ceiling | shed non-essential load |

## User-facing override policy

The system may allow explicit override for expensive actions, but only
when the user sees:

- estimated cost range
- estimated duration
- affected context scope
- why the action is being blocked or warned

No hidden override.

## Evaluation guardrails

A model or prompt route should be disabled or downgraded if:

- hallucination / unsupported claim rate exceeds threshold in evaluation
- schema parse failure rate rises above acceptable level
- user ignore/reject rate for a suggestion type becomes persistently high
- cost per accepted suggestion becomes economically unjustifiable

## Operational review cadence

The operator should review monthly:

- top cost-driving operations
- acceptance vs ignore rate by suggestion type
- queue backlog patterns
- average prompt size by operation
- fallback frequency
- provider failure frequency

## Open questions

- whether user budgets should default lower or higher
- whether archive-wide analyses should require explicit opt-in always
- whether some premium operations should be prepaid or quota-based

## Minimum runtime acceptance gate

The system is not runtime-ready until it can demonstrate:

- cost warnings trigger at configured thresholds
- expensive operations prompt before execution
- heavy operations queue instead of blocking the UI
- fallback works when provider errors are simulated
- host-pressure throttling prevents the API from becoming unusable
