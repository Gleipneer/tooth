# Asynchronous Jobs, Events and Pipelines

Many operations in the Text OS are long‑running or resource intensive
and must be handled outside of the request/response cycle.  This
document describes the job system, event model and typical
pipelines.

## Job model

As defined in the domain model, a **Job** represents a unit of work
executed asynchronously.  Jobs have types (import, export,
embedding, analysis) and status states (pending, running, completed,
failed).  A job manager component monitors job queues and dispatches
workers.

### Worker architecture

* **Job queue**: A persistent queue (e.g., Redis, PostgreSQL or
  RabbitMQ) stores pending jobs.  Each job record includes
  parameters and priority.
* **Workers**: Processes or threads that poll the queue, claim jobs
  and execute them.  Workers can be scaled horizontally.
* **Job executor**: A library that wraps job execution with error
  handling, progress reporting and status updates.
* **Cron scheduler**: Schedules recurring jobs (e.g., nightly
  embedding refresh, daily resurfacing).

### Progress and cancellation

Jobs report progress as a float between 0 and 1.  The UI polls or
subscribes to job updates to show progress bars.  For long jobs,
support cancellation: the user may cancel a job; the worker should
check periodically for a cancel flag and abort gracefully.

## Event model

Events provide a decoupled way to notify the system of domain
changes.  They can be implemented via a message bus or simple
observer pattern.  Key events include:

| Event | Payload | Trigger |
| --- | --- | --- |
| `raw_text_created` | RawText ID, metadata | After saving new RawText |
| `draft_version_created` | Draft ID, parent ID | After applying diff |
| `draft_frozen` | Draft ID | When user freezes a draft |
| `book_created` | Book ID | On new book |
| `outline_updated` | Book ID | When outline changes |
| `suggestion_applied` | Suggestion ID, draft ID | When suggestion applied |
| `import_completed` | Job ID | When import job finishes |
| `export_completed` | Job ID, file path | When export job finishes |
| `embedding_refresh_required` | Project ID | When new text ingested |

Event handlers may enqueue jobs.  For instance, when a new RawText
is created, a handler can schedule an `embedding` job to update the
semantic index.

## Pipelines

### Ingestion pipeline

1. **File upload**: User uploads file via API/UI.
2. **Job creation**: An `import` job is created with reference to the
   uploaded file.
3. **Processing**: Worker reads the file, splits it into logical
   units (chapters or paragraphs), extracts metadata, detects
   language and type.
4. **Raw texts creation**: For each unit, create a RawText record
   and store content.  Emit `raw_text_created` events.
5. **Embedding**: Handler listens to `raw_text_created` and
   schedules `embedding` jobs.
6. **Completion**: When all units processed, job status →
   `completed`.  Errors set status → `failed` with message.

### Embedding pipeline

1. **Trigger**: On `raw_text_created` or scheduled refresh.
2. **Job creation**: Create `embedding` job with list of text IDs.
3. **Processing**: Worker reads content, chunks into paragraphs,
   generates embeddings via provider API, stores vectors in the
   vector index.
4. **Progress**: Report progress per chunk.  Catch and retry
   failures.
5. **Completion**: Emit event (optional) to update search index.

### Export pipeline

1. **Trigger**: User requests export; API creates `export` job.
2. **Validation**: Worker validates book completeness.
3. **Assembly**: Flatten outline, read text files, assemble
   document.  For PDF/EPUB, call external library.
4. **Write file**: Store output in object storage; update job
   result with file path.
5. **Completion**: Emit `export_completed` event.  UI notifies user
   and provides download link.

### Analysis pipeline (P1)

1. **Trigger**: User requests theme analysis across project.
2. **Job creation**: Create `analysis` job with project ID.
3. **Processing**: Worker retrieves all relevant drafts/raw texts,
   runs embedding clustering or topic modelling, generates report.
4. **Result**: Store analysis report in database; produce human
   readable summary; optionally schedule summarisation job.

### Maintenance and housekeeping jobs

* **Backup**: Scheduled job to back up DB and files.
* **Cleanup**: Delete expired temporary files or embeddings.
* **Cost audit**: Summarise AI usage and send reports to users.

## Idempotence and retries

Jobs should be idempotent: running the same job twice produces the
same result or recognises it has already run.  For example, if a
file has been imported previously, the import job should skip or
deduplicate the content.

When a job fails, the user may retry.  The new job uses the same
input parameters.  Workers should not assume that partial state
exists (unless the job type supports resumable execution).

## Monitoring

The job system should expose metrics (jobs queued, running,
completed, failed, average duration) and logs for debugging.  A
dashboard in the observability module displays active and past jobs.

Asynchronous processing ensures the UI remains responsive and
enforces separation between user‑initiated actions and heavy
computations.