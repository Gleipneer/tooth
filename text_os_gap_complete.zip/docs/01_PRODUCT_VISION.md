# Product Vision

## Purpose

The Text OS aims to provide authors and writers with a
deterministic, trustworthy environment in which to capture,
organise, edit and publish their texts.  Unlike generic AI writing
assistants that focus on generating prose, the Text OS treats raw
text as sacrosanct, gives users fine‑grained control over AI
interventions, and makes the creative process transparent and
reproducible.  The system harnesses the power of large language
models to suggest improvements, structure narratives and surface
patterns without ever concealing the origin of content or merging AI
output into the author’s words without consent.

## Problems addressed

Writers today face several challenges:

- **Fragmentation of notes and drafts.** Ideas live in multiple
tools—notes apps, email, voice memos and paper journals—and
writers struggle to see connections between them.
- **Opaque AI assistants.** Current AI tools generate text but
rarely provide sources or insight into how suggestions were
derived, leading to hallucinations and mistrust.
- **Version chaos.** Without a rigorous versioning system,
writers lose track of revisions, making it hard to revert changes
or explore alternative directions.
- **Difficulty assembling long‑form work.** Moving from a set of
fragments to a coherent book or collection requires labourious
copying, pasting and reformatting.
- **Lack of contextual recommendations.** Writers often need to
remember themes, motifs or open threads across years of writing.

## What the Text OS is

- A **personal writing operating system** that organises all
textual material into a unified, searchable, interlinked corpus.
- A **chat‑based assistant** that analyses user‑selected text in
context, proposes improvements and structural changes, and offers
next‑step suggestions based on the writer’s goals.
- A **book engine** that generates and manages outlines, mapping
raw text fragments into chapters and sections while exposing
missing connections and redundancy.
- A **version control system** for prose, enabling non‑destructive
edits, branches and diffs so that writers can explore different
revisions without fear.
- An **AI orchestrator** that routes tasks to appropriate models
(e.g., classification, rewriting, thematics) and returns
structured outputs with evidence links.

## What the Text OS is not

- It is **not** a generic creative writing generator; it does not
produce entire works autonomously.
- It is **not** a blogging platform or CMS; publishing is supported
through export but the focus is on manuscript development.
- It is **not** a closed system; the architecture intentionally
allows import/export and avoids vendor lock‑in.

## Product promise

By using Text OS, writers will:

- Preserve every idea and draft without losing track of origins.
- Gain insights into their writing through thematic, stylistic and
  structural analysis.
- Confidently explore revisions and alternatives with full
  reversibility.
- Assemble long‑form works with clear guidance on organisation and
  missing pieces.
- Maintain trust in AI assistance through transparency,
  audibility and explicit apply steps.

## “Text OS” thesis

The term “Text OS” reflects an ambition to treat written material
with the same seriousness that an operating system treats files and
processes.  Just as an OS manages resources deterministically and
provides clear APIs for applications, the Text OS manages textual
resources, enforces invariants and exposes well‑defined contracts
for AI operations, storage and retrieval.  This foundation enables
reliability and composability that typical writing tools lack.
