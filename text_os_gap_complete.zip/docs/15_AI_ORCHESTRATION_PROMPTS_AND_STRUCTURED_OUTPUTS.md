# AI Orchestration, Prompts and Structured Outputs

The Text OS relies on AI models for various tasks—analysis,
rewriting, structural suggestions and next‑step guidance.  Orchestration
refers to selecting the appropriate model, constructing prompts with
explicit context and parsing structured outputs.  This document
defines the roles, prompt patterns and output schemas.

## AI roles

Different tasks require different specialisations.  The system uses
roles to route requests:

1. **Archivist** – Handles ingestion classification (language, text
   type) and deduplication.  Uses lightweight models for efficiency.
2. **Editor** – Performs rewriting tasks: shortening, expanding,
   clarifying, tone shifting.  Requires a deep model to preserve
   voice.
3. **Structural Analyst** – Analyses drafts and outlines for
   coherence, themes, gaps and redundancies.  Returns structured
   analyses with evidence.
4. **Book Architect** – Generates outline suggestions, intros and
   structural reorderings based on a book’s outline and assigned
   drafts.
5. **Next‑Step Guide** – Proposes a limited set of next actions
   given the user’s context (e.g., “revisit theme X”, “assign text
   to chapter Y”).
6. **Continuity Guardian** – Detects inconsistencies across drafts
   and versions (e.g., conflicting descriptions) and flags them for
   review.

The orchestration layer selects the appropriate role, model size and
temperature settings.  Roles may share underlying models but have
distinct system prompts and output schemas.

## Prompt construction

Prompts are constructed deterministically by combining:

1. **System message** – Defines the role, behaviour, format and
   policies.  Example:

   ```
   You are a Structural Analyst for a personal writing system.  You
   must analyse the provided texts and outline structure to identify
   gaps and redundancies.  Cite passages by ID when making
   observations.  Do not invent content.  Answer in the JSON format
   specified below.
   ```

2. **Context payload** – A structured list of text fragments,
   outline nodes, style profiles and decision log entries.  Each
   fragment is prefaced with metadata (ID, title, source type,
   creation date).

3. **User message** – The user’s instruction or question.  It may
   contain placeholders filled by the UI (e.g., rewrite type).  The
   user message should be clear and specify desired outputs.

4. **Output schema** – A description of the JSON schema expected
   from the model.  This is included in the system message or
   appended as a hidden instruction.  For example, a rewrite schema
   might be:

   ```json
   {
     "type": "rewrite",
     "diff": {
       "ops": [ {"op": "replace", "text": "..."}, ... ]
     },
     "rationale": "string"
   }
   ```

Prompts must be free of ambiguous pronouns (“it”, “that”).  All
references use explicit IDs.

## Structured output patterns

### Rewrite output

The `Editor` role outputs:

```json
{
  "type": "rewrite",
  "operation": "shorten|expand|clarify|tone_shift|rhythm",
  "diff": [
    {"op": "replace", "start": 23, "end": 42, "text": "new text"},
    {"op": "delete", "start": 45, "end": 50},
    {"op": "insert", "index": 75, "text": "added text"}
  ],
  "notes": "Editor notes explaining the rationale"
}
```

The client reconstructs the revised text from the diff and displays
a side‑by‑side comparison.  The `start`/`end` offsets refer to
character positions in the original passage; if offsets are stale,
the suggestion is marked expired.

### Analysis output

The `Structural Analyst` role returns:

```json
{
  "type": "analysis",
  "themes": [
    {"name": "spring", "evidence": ["rawtext:uuid#5", "draft:uuid#3"]},
    {"name": "memory", "evidence": ["rawtext:uuid#8"]}
  ],
  "gaps": [
    {"outline_node": "chapter:uuid#2", "description": "No text assigned"},
    {"outline_node": "section:uuid#5", "description": "Theme X absent"}
  ],
  "redundancies": [
    {"texts": ["draft:uuid#9", "draft:uuid#12"], "description": "Similar content"}
  ],
  "notes": "Overall assessment"
}
```

### Next‑step output

The `Next‑Step Guide` outputs:

```json
{
  "type": "next_steps",
  "actions": [
    {
      "action": "assign_text",
      "target": "chapter:uuid#2",
      "recommendation": "Assign the poem 'Spring Dawn' to this chapter"
    },
    {
      "action": "create_outline_node",
      "parent": "part:uuid#1",
      "node_type": "chapter",
      "title": "New Beginnings",
      "rationale": "To balance the narrative arc"
    }
  ]
}
```

### Book architect output

The `Book Architect` role may propose reorderings:

```json
{
  "type": "structure_suggestion",
  "reorder": [
    {"node": "chapter:uuid#3", "before": "chapter:uuid#2"}
  ],
  "insert": [
    {"parent": "part:uuid#1", "node_type": "chapter", "title": "Interlude"}
  ],
  "delete": [
    {"node": "section:uuid#7"}
  ],
  "notes": "Reasons for changes"
}
```

These structured outputs allow the client to show actionable cards
and to apply changes deterministically.

## Error handling and refusal patterns

* If the prompt exceeds the model’s context length, the orchestration
  layer should truncate context fragments or ask the user to reduce
  input.  The AI must not hallucinate missing context.
* If the user requests an operation outside of policy (e.g., asking
  the AI to merge drafts automatically), the AI must refuse
  politely and cite the policy: “I’m sorry, but I cannot apply
  changes automatically.  I can suggest a diff for you to review.”
* If the model detects that the context provided is incomplete or
  contradictory, it should ask clarifying questions: “Which version
  of this draft should I use? The one from 2025 or the current
  version?”

## Logging and reproducibility

Every AI call logs:

* Timestamp and user ID
* Role invoked and model name
* Full system and user messages (redacted for privacy when stored)
* Context object IDs and retrieval parameters
* Model output (raw JSON)
* Cost in tokens and dollars

The logging ensures that suggestions can be audited, reproduced and
debugged.  It also supports cost monitoring and improvement of
prompts.

## Future considerations

* **Prompt recipes**: Allow users to save custom prompt templates
  with placeholders.  Recipes would be versioned and shareable.
* **Model fine‑tuning**: Support user‑level fine‑tuning for style or
  domain.  Requires separate infrastructure and governance.
* **Explainability**: Provide explanations for why the model made
  certain suggestions (e.g., attention maps or example passages).  This
  is an emerging research area.

Proper orchestration and structured outputs ensure the AI remains a
controlled assistant rather than an uncontrolled generative engine.