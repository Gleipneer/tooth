# Risks, Open Questions and Decision Log

This document tracks identified risks, unresolved questions and key
decisions.  Keeping this log transparent allows stakeholders to
understand uncertainties and the rationale behind architectural
choices.

## Risk register

| Risk | Impact | Likelihood | Mitigation |
| --- | --- | --- | --- |
| **AI hallucination or incorrect suggestions** | Users may follow flawed advice, leading to poor writing or structural errors. | Medium | Use deterministic context assembly, require explicit apply, log AI outputs, and build evaluation checks.  Provide evidence for suggestions. |
| **Cost overruns due to AI usage** | Unexpected charges could exceed budgets and deter users. | Medium | Implement cost budgets, show cost estimates before calls, use cheaper models when possible. |
| **Model/API changes by providers** | Output formats or behaviours may change, breaking prompt compatibility. | High | Monitor provider updates, version prompts, implement robust parsing and fallback models. |
| **Data loss or corruption** | Loss of user texts would be catastrophic. | Low | Use backups, file and DB checksums, atomic writes, and test restore procedures. |
| **Security breach** | Exposure of sensitive writings or API keys. | Low | Encrypt data at rest and in transit, use secrets management, enforce least privilege, monitor logs. |
| **User adoption and learning curve** | Complexity may overwhelm users. | Medium | Progressive disclosure in UI, clear onboarding, templates, and excellent documentation. |
| **Scalability limitations** | System may slow down with large archives (>100k texts). | Medium | Design efficient indexes, paginate queries, use lazy loading and caching. |
| **Multi‑user complexity** | Implementing permissions and collaborative editing is challenging. | Medium | Defer until core stabilises; design modular permission model and test thoroughly. |
| **Regulatory compliance** | Laws (e.g., GDPR) require right to be forgotten and data portability. | Medium | Implement deletion and export capabilities; log access; track user consents. |

## Open questions

* **What embedding model provides the best semantic search for
  creative writing?**  Evaluate models (OpenAI, sentence‑transformers)
  on poetry and prose corpora.  Need benchmark and quality metrics.
* **How to handle multi‑language projects?**  Should the search index
  separate languages or combine them?  How to normalise cross‑lingual
  embeddings?  Requires research and user feedback.
* **Where to store extremely long works?**  For novels exceeding
  context limits, should chapters be separate RawTexts or one large
  text?  The current design favours splitting, but guidelines must be
  defined.
* **How to support interactive diagrams or non‑linear narratives?**
  The current outline system assumes linear progression.  Should
  graph‑based structures be allowed?  Consider for P2.
* **What is the appropriate licensing and usage policy for AI
  providers?**  Ensure users know whether their data is used for
  model training; offer provider alternatives.
* **How to measure and improve user trust?**  Consider surveys,
  feedback forms and usage analytics.  Identify features that build
  trust (e.g., transparency, control) and those that erode it.
* **Offline mode feasibility**: How to implement reliable syncing and
  conflict resolution for offline editing, especially with AI
  suggestions queued?  Requires design and conflict algorithms.
* **Multi‑user version control semantics**: How to merge edits from
  different authors?  Use CRDTs or patch‑based merges?  Evaluate
  complexity and library support.

Open questions should be revisited regularly and either resolved or
documented as longer‑term research tasks.

## Decision log

The following decisions have been made via ADRs or project
discussions.  Each entry references the relevant ADR and the
rationale.  New decisions should be added here with date and status.

| Date | Decision | ADR | Rationale |
| --- | --- | --- | --- |
| 2026‑04‑20 | Use a hybrid storage model (Markdown files + PostgreSQL) for canonical data. | ADR‑002 | Balances durability, portability and query performance. |
| 2026‑04‑20 | Enforce explicit apply for all AI‑generated changes. | ADR‑003 | Maintains user control and auditability. |
| 2026‑04‑20 | Use deterministic context assembly for AI prompts. | ADR‑004 | Prevents hallucination and ensures reproducibility. |
| 2026‑04‑20 | Represent books as outline trees with assignments. | ADR‑005 | Flexible, supports multiple structures and templates. |
| 2026‑04‑20 | Implement hybrid search (FTS + vector) with ranking heuristics. | ADR‑006 | Provides both precision and semantic recall. |
| 2026‑04‑20 | Abstract AI providers behind a common interface. | ADR‑007 | Allows switching providers without core changes. |
| 2026‑04‑20 | Start with single user; plan for multi‑user later. | ADR‑008 | Reduces initial complexity, design for expansion. |

## Updating this log

Maintain this file as a living document.  When new risks emerge or
questions are answered, update the relevant section.  When a decision
is made, add a row with the date, description, ADR reference and
rationale.  This log must be referenced in retrospectives and design
reviews.