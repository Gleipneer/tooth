# Model Routing, Costs and Provider Policy

This document defines how the Text OS selects AI models for tasks,
controls costs, handles failures and enforces provider policies.  It
ensures predictable behaviour, budget transparency and flexibility to
adopt new models or providers.

## Model inventory

At launch the system integrates with the OpenAI API.  Models are
grouped by capability and cost:

| Model | Capability | Typical token cost | Use cases |
| --- | --- | --- | --- |
| **GPT‑5.4** | Highest quality long‑context model | \$X/1K tokens (variable) | Deep analysis, complex rewrites, book architecture suggestions |
| **GPT‑5.4 mini** | Cheaper, shorter‑context version | \$Y/1K tokens | Classification, routing, summarisation, short rewrites |
| **Embeddings model** | Generates vector embeddings | \$Z per call | Semantic search, style profiling |
| **Whisper‑like** | Speech‑to‑text | \$A per minute | Audio transcription (P1) |

Providers may update models or pricing.  The system should retrieve
model lists and costs dynamically when possible.  Configurations are
versioned.

## Task‑to‑model routing

The orchestration layer routes tasks based on:

1. **Task complexity**: Use lightweight models for simple
   classification or summarisation; heavy models for nuanced
   rewriting and structural analysis.
2. **Context length**: If the context exceeds the limit of the
   selected model, either trim context or choose a larger model.
3. **Cost budget**: If the user or project is near its monthly
   budget, down‑route to cheaper models or ask the user to confirm.
4. **User preference**: Advanced users may specify model
   preferences in their settings or per request.  Preferences are
   advisory; the system warns if a requested model is incompatible.

Routing rules are defined declaratively (e.g., YAML) so they can be
updated without code changes.  Example rule:

```yaml
rewrite:
  default_model: gpt-5.4
  short_context_threshold: 800
  short_model: gpt-5.4-mini
  cost_limit: 0.10  # USD per call
analysis:
  default_model: gpt-5.4
  fallback_model: gpt-5.4-mini
  max_tokens: 4000
```

## Cost budgets and controls

Costs accrue per API call.  The system tracks costs by user,
project and month.  Users can set budgets (e.g., \$20/month).  When
80% of the budget is reached, the system sends a warning.  When
100% is reached, the system stops processing AI requests unless the
user overrides.

Cost controls:

* **Preview cost estimation:** Before an expensive call, the UI
  displays an estimated cost based on tokens.  The user confirms
  or cancels.
* **Bulk operations throttle:** For actions that could spawn many
  requests (e.g., analysing 500 drafts), the system batches calls
  and checks cost after each batch.  The user can pause between
  batches.
* **Low‑cost mode:** Users can toggle a low‑cost mode where the
  system always selects the cheapest suitable model.  This may
  reduce output quality.

## Fallback and retry policy

Occasionally calls may fail due to provider issues or network errors.

* **Retry**: The system retries transient errors (e.g., HTTP 5XX) up
  to 3 times with exponential backoff.
* **Fallback**: If the primary model fails or returns an error
  indicating overload, the system may reroute to a secondary model
  if available.  The user is informed if fallback occurs.
* **Graceful degradation**: If all models fail, the system returns
  an error message suggesting manual operations or resubmission later.

## Provider abstraction

The system defines an internal interface for AI providers.  Key
methods include:

* `generate` – returns text or JSON completions given a prompt.
* `embed` – returns vector embeddings for texts.
* `transcribe` – converts audio to text.
* `moderate` – runs content moderation if available.

Providers implement these methods and expose capabilities and costs.
Switching providers does not require changing orchestration logic.

## Data privacy and compliance

AI providers receive user data.  The system must:

* **Anonymise or minimise** personally identifiable information
  before sending content.  E.g., redact names or external links
  unless necessary for the task.
* **Store audit logs** of what data was sent and the provider’s
  response.
* **Allow opt‑out**: Users can opt out of sending certain texts to
  providers.  Those texts will not be included in AI prompts; the
  system warns that suggestions may be limited.

## Future enhancements

* **Fine‑grained quotas**: Separate budgets for different tasks
  (analysis vs. rewriting).
* **Multiple providers**: Add open‑source or local models for
  sensitive data.  Users choose provider per project.
* **Dynamic model selection** based on latency and success rates.

Proper model routing and cost management align with the design
principles of transparency, auditability and user control.