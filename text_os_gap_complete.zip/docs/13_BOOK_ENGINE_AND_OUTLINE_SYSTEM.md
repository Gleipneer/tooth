# Book Engine and Outline System

The book engine translates a collection of drafts and raw texts into a
coherent publication.  It handles structural definition, mapping of
texts, generation of supporting matter (e.g., table of contents,
intro) and export.  This document defines the book data model,
workflow and template capabilities.

## Book object

A **BookProject** (defined in the domain model) encapsulates:

* **Metadata** – title, subtitle, description, status (draft,
  review, finalized), creation date, style profile.
* **Outline tree** – a hierarchy of **OutlineNodes** (book root,
  parts, chapters, sections).  The outline defines reading order.
* **Assignments** – each node may reference drafts or raw texts.
* **Intro, prolog, afterword** – optional nodes outside the main
  chapter hierarchy.
* **Front matter and back matter** – optional elements such as
  dedication, acknowledgments, bibliography.

## Outline system

The outline system allows users to design the structure of a book
before or alongside assigning content.  Key concepts:

* **Node types**: `book` (implicit root), `part`, `chapter`,
  `section`.  Future types could include `scene` or `poem` cards.
* **Hierarchy**: Nodes form a strict tree.  Parts may contain
  chapters; chapters may contain sections.  Sections cannot contain
  other sections by default.
* **Index ordering**: Each node has an `index_order` defining its
  order among siblings.  Users can reorder nodes via drag‑and‑drop.
* **Assignments**: Nodes can reference multiple drafts or raw texts.
  The order of assignments within a node determines insertion order
  in export.
* **Status**: Each node has state: `unassigned`, `assigned`,
  `finalized`, `archived` (see lifecycle doc).  A node must be at
  least `assigned` before finalising a book.

## Outline operations

Users interact with the outline via a dedicated tree editor:

1. **Add node**: Insert a new part, chapter or section at a
   selected location.  Provide a title; the node initially has
   `unassigned` status.
2. **Rename node**: Change the title of a node.  Renaming does not
   affect assignments.
3. **Reorder node**: Drag a node up or down among its siblings.
   The `index_order` updates accordingly.  Reordering automatically
   updates the table of contents.
4. **Assign texts**: Drag drafts or raw texts from the project tree
   onto an outline node.  The system appends them to the
   `assigned_texts` list and marks the node `assigned`.
5. **Remove assignment**: Remove a draft from a node.  The draft
   remains unchanged; the node reverts to `unassigned` if it has
   no other texts.
6. **Move assignment**: Reorder or move an assigned draft to a
   different node.  This triggers a diff in the book version.
7. **Duplicate node**: Copy a node and its assignments to create a
   variant structure (useful in exploring alternative orders).  The
   duplicate has its own ID and can diverge.
8. **Lock/finalise node**: Mark the node as `finalized`.  This
   prevents further changes unless the book is reverted to draft.

The outline editor must be responsive to large books and support
undo/redo for structural operations.

## Templates and book types

Different genres require different structures.  The book engine
supports **templates** that pre‑populate the outline and front/back
matter.  Examples:

* **Essay collection**: root → chapters (each essay).  Includes
  introduction and acknowledgments.
* **Poetry collection**: root → sections (e.g., themed sections).  May
  include notes on sources.
* **Memoir**: root → parts (life periods) → chapters (events).  May
  include prolog and epilogue.
* **Hybrid book**: mixture of essays and poems.  Allows flexible
  node types and cross‑referencing.

Templates define a starting outline.  Users can modify or extend
them.  Template definitions are stored as JSON and can be created by
users or distributed with the system.

## Generating intros and supporting matter

The AI can assist in drafting supporting material:

* **Premise and reader promise**: The user inputs the core theme or
  purpose; the AI suggests a refined premise and a reader promise
  (what the reader will gain).  The user reviews and edits.
* **Introduction**: Summarises the themes, provides context and
  outlines the structure.  The AI uses the book’s outline and
  assigned texts to produce a draft.  The intro is inserted as a
  separate node at the beginning.
* **Afterword/epilogue**: Summarises reflections after the main
  content.  Generated after the book is assembled and can refer to
  motifs and themes identified in the analysis.

All AI‑generated material is presented in the editor with diff and
requires explicit apply.

## Health checks and structural analysis

The book engine includes functions to evaluate structural health:

* **Coverage check**: Detects outline nodes with no assignments.
* **Overlap check**: Identifies drafts assigned to multiple nodes;
  flags potential redundancy.
* **Flow analysis**: AI analyses the order of chapters/sections to
  suggest reordering for narrative flow or thematic progression.
* **Length estimation**: Calculates approximate word counts per
  chapter and the whole book; helps determine pacing.

Results are surfaced in the right panel or as chat suggestions.  The
user can accept or ignore recommendations.

## Exporting a book

Export assembles the book into a single document.  Steps:

1. **Validation**: Ensure all nodes are at least `assigned` or
   `finalized`.  Warn if some nodes remain `unassigned`.
2. **Order resolution**: Flatten the outline tree into a sequence of
   nodes based on `index_order` and the hierarchy.
3. **Insert supporting matter**: Insert intro, prolog, afterword and
   front/back matter at specified positions.
4. **Concatenate texts**: For each node, insert the content of
   assigned drafts/raw texts in order.  If multiple drafts are
   assigned, insert separators or headings as configured.
5. **Generate TOC**: Build a table of contents with page numbers or
   links (depending on format).  For PDF/EPUB, generate internal
   bookmarks.
6. **Render format**: Choose Markdown (P0), EPUB or PDF (P1).  Use
   external libraries for EPUB/PDF generation.  Apply a default
   style or user‑provided template (future feature).
7. **Output file**: Save the file to disk and return a link.  The
   export job stores metadata about the export.

## Future enhancements

* **Scene cards and granular nodes**: For novel writing, add a
  `scene` node type with additional metadata (POV, setting).
* **Multiple outline variants**: Allow users to experiment with
  different structures and choose the best one.
* **Collaborative compilation**: In multi‑user mode, allow an editor
  to request chapter submissions from authors and assemble them.

The book engine is a central differentiator of the Text OS.  It
combines structure and creativity while preserving the core
invariants of explicit apply and immutable sources.