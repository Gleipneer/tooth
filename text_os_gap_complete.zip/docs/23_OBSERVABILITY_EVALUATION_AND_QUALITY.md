# Observability, Evaluation and Quality

Observability provides visibility into how the Text OS operates,
enabling debugging, optimisation and trust.  Evaluation and quality
assurance ensure that AI outputs meet user expectations and that
system performance remains robust.  This document defines logging,
metrics, tracing and evaluation strategies.

## Logging

* **Application logs**: Capture startup messages, configuration
  parameters, requests and responses, warnings, errors and stack
  traces.  Logs include correlation IDs to trace user actions across
  services.
* **AI call logs**: In addition to audit logs, store AI call
  technical metadata: latency, tokens in/out, provider status codes.
* **Job logs**: Each job writes progress messages and errors.  Logs
  are associated with job IDs for retrieval in the UI.
* Logs should be structured (e.g., JSON) for ingestion into log
  aggregation systems (Elastic, Loki) and forwarded to the
  observability dashboard.

## Metrics

Define metrics across three categories:

| Category | Examples | Purpose |
| --- | --- | --- |
| **System health** | CPU/memory usage, request rate, error rate, job queue length | Detect performance issues and capacity planning |
| **AI usage** | Number of AI calls per day, average cost per call, cumulative cost per project | Cost monitoring and budgeting |
| **User behaviour** | Number of drafts created, books exported, suggestions applied vs. ignored | Inform product decisions and detect friction points |

Metrics are scraped by a monitoring system (e.g., Prometheus).  Key
metrics trigger alerts when thresholds are exceeded (e.g., error rate
>5%).

## Tracing

Distributed tracing ties together logs and metrics across services.
When a user action triggers a series of API calls and background
jobs, a trace ID follows the request.  Tools like OpenTelemetry
instrument HTTP handlers, job workers and database queries.  Traces
help pinpoint bottlenecks or failures.

## Quality evaluation for AI outputs

AI suggestions must be evaluated systematically.  Strategies:

* **Human‑in‑the‑loop ratings**: Users can rate suggestions (useful,
  irrelevant, harmful).  Ratings feed back into prompt tuning and
  model selection.
* **Automated checks**: For rewrite tasks, compute lexical overlap
  and readability scores.  Flag suggestions that diverge too far
  from the original or violate style profiles.
* **Hallucination detection**: Check if AI analysis references
  fragments outside the provided context.  Reject outputs that
  include unsupported statements.
* **Regression tests**: Maintain a suite of test prompts with
  expected structured outputs.  Run tests after model updates to
  ensure the output schema and quality remain consistent.

## Cost observability

An AI cost dashboard shows spending trends:

* Cost per project per period (day/week/month).
* Cost per task type (rewrite, analysis, search embedding).
* Forecasted cost based on current usage rates.  Users can adjust
  budgets or usage patterns accordingly.

Alerts warn when spending approaches the budget.  The system
automatically throttles expensive tasks if necessary.

## Style preservation evaluation

When performing rewriting, ensure that the original style and tone
are preserved:

* Compare n‑gram distributions and lexical diversity before and after.
* Use style profiles as reference; compute similarity scores.
* Flag rewrites that deviate significantly.  Suggest the user
  manually review or adjust the request.

## Retrieval quality checks

* Monitor retrieval success rates: fraction of AI calls where
  retrieved fragments contained relevant information for the user’s
  question.
* Evaluate recall: use internal benchmarks to measure how often
  retrieval surfaces known relevant texts.
* Optimise ranking algorithms based on metrics (precision/recall,
  mean reciprocal rank).

## Apply safety checks

Before applying AI suggestions, run safety checks:

* Ensure the diff does not alter locked sections.
* Validate that suggestions are anchored to current draft context.
* Confirm the user has the necessary permissions (for multi‑user
  mode).
* Enforce cost limits (e.g., reject applying a suggestion if it
  triggers a chain of expensive operations).

## Regression and performance testing

* **Unit tests**: Cover domain rules, API contracts and state
  transitions.
* **Integration tests**: Simulate end‑to‑end flows (import, edit,
  analysis, export) with realistic data.
* **Load tests**: Measure performance under concurrent usage.
* **Chaos testing**: Inject failures (e.g., AI provider downtime)
  and verify graceful degradation.

Comprehensive observability and evaluation practices help maintain
trust in the system and the AI assistants.