# Backend API Contracts

The backend API exposes operations on domain objects, orchestrates
AI calls and provides search and import/export endpoints.  This
document specifies the high‑level API contracts: endpoints, HTTP
verbs, request/response schemas and error handling.  It is language
agnostic but assumes RESTful principles with JSON payloads.

> **Note:** All endpoints require authentication.  The API must
> validate that the user owns or has access to the referenced
> project.  Error responses use standard HTTP status codes and
> include a JSON body with `error`, `message` and optional
> `details` fields.

## URL conventions

* All paths are prefixed with `/api/v1` to allow versioning.
* Resource IDs are UUIDs.
* Nested resources reflect ownership (e.g., `/projects/{project_id}/rawtexts`).

## Projects

| Endpoint | Method | Description |
| --- | --- | --- |
| `/api/v1/projects` | GET | List all projects for the authenticated user. |
| `/api/v1/projects` | POST | Create a new project.  Body: `{ "name": "string" }`. Returns the project object. |
| `/api/v1/projects/{id}` | GET | Retrieve a project with metadata and summary counts. |
| `/api/v1/projects/{id}` | PATCH | Update project fields (name, description). |
| `/api/v1/projects/{id}` | DELETE | Archive a project (soft delete). |

## RawTexts

| Endpoint | Method | Description |
| --- | --- | --- |
| `/api/v1/projects/{project_id}/rawtexts` | GET | List raw texts with filter and pagination.  Query parameters: `page`, `size`, `tag`, `theme`, `type`, `q` (search term). |
| `/api/v1/projects/{project_id}/rawtexts` | POST | Create a raw text.  Body: `{ "title": "string", "content": "string", "tags": ["tag_id"], ... }`.  Returns the raw text. |
| `/api/v1/rawtexts/{id}` | GET | Retrieve full raw text content and metadata. |
| `/api/v1/rawtexts/{id}` | PATCH | Update metadata only (tags, themes, title).  Content cannot be edited. |
| `/api/v1/rawtexts/{id}/archive` | POST | Archive the raw text. |

## Drafts

| Endpoint | Method | Description |
| --- | --- | --- |
| `/api/v1/projects/{project_id}/drafts` | GET | List drafts with filters: `raw_text_id`, `branch`, `status`. |
| `/api/v1/rawtexts/{raw_text_id}/drafts` | POST | Create a draft from a raw text or another draft.  Body: `{ "parent_draft_id": "uuid" (optional), "branch": "string" }`.  Returns the draft object. |
| `/api/v1/drafts/{id}` | GET | Retrieve full draft content and metadata. |
| `/api/v1/drafts/{id}` | PATCH | Update metadata (tags, themes, status).  Content cannot be edited directly; editing happens via diff operations. |
| `/api/v1/drafts/{id}/versions` | GET | List version history; returns an array of draft IDs and metadata. |
| `/api/v1/drafts/{id}/freeze` | POST | Freeze a draft (status `frozen`). |
| `/api/v1/drafts/{id}/archive` | POST | Archive a draft. |

Content updates are performed via diff application:

| Endpoint | Method | Description |
| --- | --- | --- |
| `/api/v1/drafts/{id}/apply_diff` | POST | Apply a diff patch to the draft.  Body: `{ "diff": [ ... ], "suggestion_id": "uuid" (optional) }`.  Returns the new draft version. |

## Books and outline nodes

| Endpoint | Method | Description |
| --- | --- | --- |
| `/api/v1/projects/{project_id}/books` | GET | List books. |
| `/api/v1/projects/{project_id}/books` | POST | Create a book.  Body: `{ "title": "string", "subtitle": "string", "description": "text" }`. |
| `/api/v1/books/{id}` | GET | Retrieve book metadata and outline summary. |
| `/api/v1/books/{id}` | PATCH | Update book metadata (title, subtitle, description, status). |
| `/api/v1/books/{id}/archive` | POST | Archive a book. |
| `/api/v1/books/{id}/outline` | GET | Retrieve full outline tree with assignments. |
| `/api/v1/books/{id}/outline` | POST | Replace the entire outline.  Body: JSON tree of nodes.  Used for bulk import or template application. |
| `/api/v1/outline_nodes/{node_id}` | PATCH | Update a node (title, index order, status). |
| `/api/v1/outline_nodes/{node_id}/assign` | POST | Assign a draft or raw text to a node.  Body: `{ "text_id": "uuid", "position": integer }`. |
| `/api/v1/outline_nodes/{node_id}/unassign` | POST | Remove assignment.  Body: `{ "text_id": "uuid" }`. |

## Conversations and suggestions

| Endpoint | Method | Description |
| --- | --- | --- |
| `/api/v1/projects/{project_id}/conversations` | GET | List conversations.  Filters: `context_type`, `text_id`. |
| `/api/v1/projects/{project_id}/conversations` | POST | Create a conversation.  Body: `{ "context_refs": [ {"type": "rawtext", "id": "uuid"}, ... ] }`.  Returns conversation ID. |
| `/api/v1/conversations/{id}` | GET | Retrieve conversation messages and metadata.  Supports pagination. |
| `/api/v1/conversations/{id}/messages` | POST | Append a user message.  Body: `{ "content": "string" }`.  Triggers AI reply. |
| `/api/v1/suggestions/{id}` | GET | Retrieve suggestion details. |
| `/api/v1/suggestions/{id}/apply` | POST | Apply the suggestion.  Body: `{ "target_draft_id": "uuid" }`.  Returns new draft version. |
| `/api/v1/suggestions/{id}/ignore` | POST | Mark suggestion as ignored. |

## Search

| Endpoint | Method | Description |
| --- | --- | --- |
| `/api/v1/projects/{project_id}/search` | GET | Search across texts and drafts.  Query parameters: `q` (keyword), `semantic` (boolean), `limit`, `filters...`.  Returns matches with snippet and metadata. |
| `/api/v1/projects/{project_id}/similar` | GET | Semantic similarity search for a given text segment.  Params: `draft_id` or `rawtext_id`, `start`, `end`, `limit`. |

## Import and export jobs

| Endpoint | Method | Description |
| --- | --- | --- |
| `/api/v1/projects/{project_id}/import_jobs` | POST | Start an import.  Body includes file references or text payload.  Returns job ID. |
| `/api/v1/jobs/{id}` | GET | Retrieve job status and progress. |
| `/api/v1/projects/{project_id}/export_jobs` | POST | Start an export.  Body: `{ "book_id": "uuid", "format": "markdown|epub|pdf" }`. |

## Style profiles

| Endpoint | Method | Description |
| --- | --- | --- |
| `/api/v1/projects/{project_id}/style_profiles` | GET | List style profiles. |
| `/api/v1/projects/{project_id}/style_profiles` | POST | Create a style profile.  Body: parameters or reference texts. |
| `/api/v1/style_profiles/{id}` | GET | Retrieve profile details. |

## Error responses

Errors use standard HTTP status codes:

* **400 Bad Request** – Invalid input, missing parameters.
* **401 Unauthorized** – Missing or invalid authentication.
* **403 Forbidden** – User does not own the project/resource.
* **404 Not Found** – Resource does not exist.
* **409 Conflict** – Violates state machine (e.g., applying diff to frozen draft).
* **422 Unprocessable Entity** – Valid request but cannot perform action due to business rule (e.g., assigning draft to an archived node).
* **429 Too Many Requests** – Exceeded rate or budget limits.
* **500 Internal Server Error** – Unexpected server error.

Responses include JSON:

```json
{
  "error": "BadRequest",
  "message": "Tag name exceeds 50 characters",
  "details": { "field": "name", "max_length": 50 }
}
```

## API evolution

Changes to the API must be versioned.  Deprecations are announced
with sunset dates.  Breaking changes require a new API version
(`v2`).  Documentation is updated accordingly, and clients must
explicitly opt in to new versions.