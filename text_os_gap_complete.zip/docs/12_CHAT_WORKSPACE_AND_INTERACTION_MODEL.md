# Chat Workspace and Interaction Model

The chat workspace is where users interact with AI assistants and
review structured suggestions.  It must feel familiar to ChatGPT
users while being tightly integrated with the Text OS domain model.
This document defines the chat behaviours, message types and
interaction patterns.

## Conversation context

Each conversation is associated with a project and optionally
specific objects (raw texts, drafts, book nodes).  The context defines
what information is available to the AI and helps scope the chat
history.

* **Project context**: Access to all texts and metadata within the
  selected project.  Suitable for high‑level questions (e.g., “What
  themes appear across my poetry this year?”).
* **Text/draft context**: Ties the conversation to a particular
  document.  The AI sees the full text (subject to privacy filters)
  and can offer rewriting and analysis.  This is the default when
  launching chat from an editor.
* **Book context**: Links to a book project or specific outline
  node.  The AI can inspect the outline and assigned texts to
  propose structural changes.

Users can **pin** multiple context objects to a conversation.  The
right panel shows pinned items and allows removing them.  Pinned
context influences the AI prompt assembly; removing a pin reduces
context.

## Message types

| Type | Sender | Description |
| --- | --- | --- |
| **User message** | User | Free‑form text written by the user.  May include explicit instructions or questions. |
| **System message** | System | Internal guidance sent to the AI (e.g., system prompt instructing the model on style).  Not visible to the user but stored for audit. |
| **Assistant message** | AI | Response from the AI model.  May contain plain text and structured cards (see below). |
| **Action card** | System/Assistant | A UI element attached to an assistant message representing a suggested action (e.g., apply diff, create outline node).  Action cards are interactive. |
| **Suggestion record** | System | Persisted representation of an AI suggestion.  Linked to action cards. |

Messages appear chronologically.  Time stamps are shown, and long
messages collapse with a “Read more” toggle to improve readability.

## Structured outputs and action cards

Assistant messages often include structured outputs.  For example, an
analysis might return a list of themes with evidence citations, while
a rewrite returns a diff patch.  The UI wraps these into cards with
actions:

* **Analysis card**: Shows a list of identified themes/motifs or
  structural gaps.  Each item links to the evidence (highlighted
  passages).  A user can click to create tags or add notes.
* **Rewrite card**: Shows before/after text with changes
  highlighted.  Buttons: “Apply” (creates new draft version),
  “Apply to new branch”, “Ignore”.
* **Next‑step card**: Lists recommended tasks with short rationales.
  Each task has a button to accept.  Accepting triggers a specific
  workflow (e.g., open a new draft, start an outline operation).
* **Outline suggestion card**: Proposes reordering or adding
  outline nodes.  Buttons allow applying structural changes.

Cards remain visible in the right panel under “AI suggestions” until
applied or ignored.  This ensures users can revisit suggestions
later.

## Conversation lifecycle

1. **Start conversation:** Initiated from a project, text or book.
2. **Set context:** Default context is auto‑pinned based on entry
   point.  User can pin or unpin additional context objects.
3. **Send message:** User writes a prompt.  Hitting Enter sends it.
   Multi‑line messages are supported (shift+Enter).
4. **Assemble prompt:** The system constructs the AI prompt by
   combining the system message (instructions), pinned contexts
   (text excerpts, outlines, style profiles) and user message.
5. **AI response:** The model returns a structured output.  The UI
   displays plain text explanation followed by any cards.
6. **Action on suggestions:** Users may apply or ignore cards.  Cards
   remain accessible in the right panel.  Applying triggers domain
   events and logs the action.
7. **Continue conversation:** The history persists.  Context can be
   adjusted at any time.  Expired suggestions are marked and
   hidden by default.

## Conversation branching

Users may branch a conversation to explore different paths:

* **Duplicate**: Creates a new conversation with the same history
  and context up to a chosen point.  This allows exploring
  alternative AI suggestions without losing the original thread.
* **Reference**: Conversations can reference each other (e.g., “See
  analysis in conversation #12”).
* **Merge**: Not supported.  Conversations remain separate to
  preserve auditability.

Branching is important for experimentation; however, users should be
encouraged to close unused branches to avoid clutter.

## Handling uncertainty and limits

* **Clarification questions:** If the AI does not have enough
  context or the user’s request is ambiguous, it should ask
  clarifying questions rather than guessing.
* **Token and cost limits:** The system should warn users when
  context size approaches the model’s token limit or when the
  monthly budget is nearly exhausted.  Users can drop pins or
  simplify requests to reduce cost.
* **Refusal policy:** If a user asks the AI to perform tasks that
  violate invariants (e.g., auto‑apply changes), the AI must refuse
  and explain the policy.

## Future enhancements

* **Voice input and TTS**: Support voice commands and read‑aloud
  responses.
* **Collaborative chat**: Multiple users in the same conversation
  with presence indicators and shared suggestions (P2).
* **User‑defined personas**: Allow users to save custom system
  messages that shape the assistant’s tone or behaviour.

The chat workspace must remain a safe, controlled environment where
AI acts as an assistant and all actions that impact canonical data
require explicit confirmation.