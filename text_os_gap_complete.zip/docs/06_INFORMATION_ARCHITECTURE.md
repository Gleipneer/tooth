# Information Architecture

The information architecture (IA) describes how the Text OS organises
and relates its content and interface elements.  A clear IA helps
users understand where they are, what they can do, and how to
navigate through projects, texts and AI interactions.  It also
guides database design and API contracts.

## High‑level structure

At the top level the system consists of **Projects**, each of which
may contain:

* **Books** – collections of texts arranged into a hierarchy of
  parts, chapters and sections.
* **Raw texts** – immutable pieces of user‑generated or imported
  content.  These are the primary source of all drafts.
* **Drafts** – editable versions derived from raw texts.  A draft
  may belong to multiple projects but is owned by the user.
* **Conversations** – chat threads associated with a project or
  specific text/draft.  Conversations are stored with context and
  transcripts.
* **Collections** – user‑defined groupings of texts and drafts
  across or within projects.  Collections are for quick access and
  do not affect canonical relationships.
* **Tags and themes** – metadata used to classify texts, drafts and
  books.  Tags are free‑form; themes come from user input or AI
  analysis.

![IA high level](ia-high-level.png)

*Figure: top‑level information architecture of the Text OS*

## Navigation model

Users primarily navigate via a left‑hand rail listing **Projects**.
Selecting a project reveals child items in a nested list:

```
Projects
├── Personal Anthology
│   ├── Books
│   │   ├── Lost Poems
│   │   └── Essays 2025
│   ├── Raw Texts
│   │   ├── 2026‑03‑21 – Morning notes
│   │   ├── 2026‑03‑22 – Haiku draft
│   │   └── …
│   ├── Drafts
│   │   ├── Haiku draft – v1
│   │   └── Morning notes – v2
│   ├── Collections
│   │   ├── Poems on Spring
│   │   └── Epiphanies
│   ├── Conversations
│   │   ├── Conversation with Haiku
│   │   └── Project chat
│   └── Tags & Themes
└── Manuscript for Henrik
    └── …
```

Selecting a **Book** opens an outline view in the right panel.  The
main workspace can then show the editor or chat for the selected
chapter.  Selecting a **Raw Text** or **Draft** opens the editor
directly.  **Conversations** open the chat workspace.  **Tags** and
**Themes** open search/filter views.

## Object relationships

The relationships between objects are as follows:

* A **Project** owns many books, raw texts, drafts and
  conversations.  Objects may be referenced in multiple projects but
  have a primary project for permissions and default context.
* A **Book** belongs to one project and contains a tree of
  **OutlineNodes** (parts, chapters, sections).  An outline node may
  reference zero or more **Drafts** or **RawTexts**.  A draft may
  be referenced in multiple nodes (e.g., reused in a different
  context).
* A **RawText** is immutable and can spawn multiple **Drafts**.  A
  draft references one raw text as its origin and may chain to
  parent drafts for version history.  Drafts and raw texts have
  many‑to‑many relationships with tags, themes and collections.
* A **Conversation** may be linked to a project, a book, a raw text
  or a draft.  This determines the default context for AI
  operations.
* **Collections** are many‑to‑many groupings over raw texts and
  drafts.  They do not imply order unless explicitly ordered by the
  user.

## Metadata and tagging

Metadata about texts drives search, retrieval and analysis.  Each
RawText and Draft record stores:

| Attribute | Purpose |
| --- | --- |
| Title | Optional human‑readable title extracted from the first line or provided by the user. |
| Created/Imported date | Timestamp for chronology. |
| Language | ISO language code detected or supplied. |
| Text type | Category such as poem, prose, note, essay. |
| Tags | User‑defined labels. |
| Themes | AI‑ or user‑defined concepts (e.g., “spring”, “memory”). |
| Origin | Path or source indicating whether the text was typed, pasted, imported or captured from audio. |
| Length | Character or word count; used for search filters and cost estimation. |

Themes differ from tags in that they often emerge from AI analysis and
may be shared across multiple users in the future.  Tags are
user‑specific and aid organisation.  Both support multi‑value and
hierarchical structures.

## Canonical vs derived data

Canonical data—the RawText content, draft versions, outlines and
book definitions—lives in the primary storage system.  Derived data
includes embeddings for semantic search, indexes for full‑text
search, and cached analysis results.  Derived data can be rebuilt
from canonical sources and must not be edited directly.

## Rationale

This information architecture follows the design principles of
immutability, determinism and progressive disclosure.  The hierarchy
ensures that users always understand context (e.g., which project or
book they are in) and can easily navigate between creative tasks,
organisation and AI interaction.  The separation between canonical
and derived data supports reproducibility and portability.