# Database Schema and Storage Model

The Text OS uses a hybrid storage model: canonical text content is
stored as Markdown files on disk for portability, while metadata,
relationships and derived data are stored in a relational database.
This document outlines the database schema and storage strategies.

## Storage overview

| Component | Storage medium | Rationale |
| --- | --- | --- |
| **Raw text content** | Filesystem (e.g., `/var/textos/raw/{uuid}.md`) | Text remains human‑readable and easily backed up.  Files can be versioned via Git or snapshots. |
| **Draft content** | Filesystem (e.g., `/var/textos/drafts/{uuid}.md`) | Drafts store full text for convenience; canonical diff chain stored in DB. |
| **Metadata, relationships, diffs** | PostgreSQL database | ACID guarantees, relational queries, transaction support. |
| **Embeddings** | Vector store (Pgvector extension or separate service) | Optimised nearest‑neighbour search. |
| **Audit logs** | PostgreSQL (append‑only) | Structured logs for AI calls, suggestions and decisions. |
| **Attachments** | Object storage (e.g., S3 or local disk with hashed names) | Handles audio, image files used for transcription or OCR. |

## Database tables

The schema reflects the domain model.  Key tables are summarised
below.  Field definitions are abbreviated; see the domain model for
complete details.

### projects

| Column | Type | Notes |
| --- | --- | --- |
| id | UUID (PK) | |
| name | VARCHAR | |
| description | TEXT | |
| created_at | TIMESTAMP | |
| archived | BOOLEAN | Soft delete flag |

### raw_texts

| Column | Type | Notes |
| --- | --- | --- |
| id | UUID (PK) | |
| project_id | UUID (FK → projects.id) | |
| content_path | VARCHAR | File path |
| title | VARCHAR | |
| language | VARCHAR(8) | |
| text_type | VARCHAR | |
| origin | VARCHAR | |
| created_at | TIMESTAMP | |
| length | INTEGER | |
| import_job_id | UUID (FK → jobs.id) | Nullable |
| archived | BOOLEAN | |

### drafts

| Column | Type | Notes |
| --- | --- | --- |
| id | UUID (PK) | |
| project_id | UUID (FK → projects.id) | |
| raw_text_id | UUID (FK → raw_texts.id) | |
| parent_draft_id | UUID (FK → drafts.id) | Nullable |
| branch_name | VARCHAR | |
| diff | JSONB | Patch from parent |
| content_path | VARCHAR | |
| created_at | TIMESTAMP | |
| status | VARCHAR | `in_progress`, `frozen`, `archived` |
| archived | BOOLEAN | |

### books

| Column | Type | Notes |
| --- | --- | --- |
| id | UUID (PK) | |
| project_id | UUID (FK → projects.id) | |
| title | VARCHAR | |
| subtitle | VARCHAR | |
| description | TEXT | |
| status | VARCHAR | `draft`, `in_review`, `finalized`, `archived` |
| style_profile_id | UUID (FK → style_profiles.id) | Nullable |
| created_at | TIMESTAMP | |
| archived | BOOLEAN | |

### outline_nodes

| Column | Type | Notes |
| --- | --- | --- |
| id | UUID (PK) | |
| book_id | UUID (FK → books.id) | |
| parent_id | UUID (FK → outline_nodes.id) | Nullable |
| node_type | VARCHAR | `book`, `part`, `chapter`, `section` |
| title | VARCHAR | |
| index_order | INTEGER | |
| status | VARCHAR | `unassigned`, `assigned`, `finalized`, `archived` |

### outline_assignments

Many‑to‑many table linking outline nodes to texts.

| Column | Type | Notes |
| --- | --- | --- |
| outline_node_id | UUID (FK → outline_nodes.id) | PK part |
| text_id | UUID | PK part; can reference either drafts.id or raw_texts.id (polymorphic). |
| text_type | VARCHAR | `draft` or `rawtext` |
| position | INTEGER | Order within node |

### conversations

| Column | Type | Notes |
| --- | --- | --- |
| id | UUID (PK) | |
| project_id | UUID (FK → projects.id) | |
| created_at | TIMESTAMP | |

### conversation_contexts

Stores pinned context objects.

| Column | Type | Notes |
| --- | --- | --- |
| conversation_id | UUID (FK → conversations.id) | PK part |
| ref_id | UUID | PK part |
| ref_type | VARCHAR | `rawtext`, `draft`, `book`, `outline_node` |

### messages

| Column | Type | Notes |
| --- | --- | --- |
| id | UUID (PK) | |
| conversation_id | UUID (FK → conversations.id) | |
| sender | VARCHAR | `user`, `assistant`, `system` |
| timestamp | TIMESTAMP | |
| content | JSONB | Stores either text or structured output |
| applied | BOOLEAN | Indicates if suggestion applied |

### suggestions

| Column | Type | Notes |
| --- | --- | --- |
| id | UUID (PK) | |
| conversation_id | UUID (FK → conversations.id) | |
| type | VARCHAR | `analysis`, `rewrite`, `structure`, `next_step` |
| input_context | JSONB | |
| output | JSONB | |
| evidence | JSONB | Array of object references |
| accepted | BOOLEAN | Null initially |
| applied_draft_id | UUID (FK → drafts.id) | Nullable |
| created_at | TIMESTAMP | |

### jobs

| Column | Type | Notes |
| --- | --- | --- |
| id | UUID (PK) | |
| project_id | UUID (FK → projects.id) | |
| type | VARCHAR | `import`, `export`, `embedding`, etc. |
| status | VARCHAR | `pending`, `running`, `completed`, `failed` |
| progress | FLOAT | 0.0–1.0 |
| error_message | TEXT | Nullable |
| input_parameters | JSONB | |
| result | JSONB | Nullable |
| created_at | TIMESTAMP | |
| started_at | TIMESTAMP | Nullable |
| finished_at | TIMESTAMP | Nullable |

### tags, themes and junction tables

`tags` and `themes` tables store tag/theme definitions.  Many‑to‑many
relationships with texts are modelled via junction tables
`rawtext_tags`, `draft_tags`, `rawtext_themes`, `draft_themes`.

### style_profiles

Stores stylistic parameters as defined in the domain model.  May be
linked to books or users.

## Indexing strategy

* **Full‑text indexes** on `raw_texts.content_path` (via external
  indexing of file content) and `drafts.content_path`.  Alternatively
  maintain a shadow text column for indexing.
* **GIN or GiST indexes** on tags and themes for efficient
  many‑to‑many queries.
* **Vector index** on embeddings table using `ivfflat` or `hnsw`
  depending on performance and update patterns.

## Storage operations

* When creating a RawText or Draft, the server writes content to a
  file and stores the path.  The content path is structured by
  object ID to avoid collisions.
* Updates to drafts produce new files; old versions remain for
  auditability.  Optional disk cleanup may remove abandoned draft
  files after a retention period.
* Backups include both the database and the filesystem.  A snapshot
  process ensures consistency between them (e.g., pausing writes or
  using transactional file systems).

## Considerations

* **Atomicity**: File write and database insert must be atomic; use
  a transaction that inserts metadata after the file is safely
  written.  If the file write fails, rollback the DB insert.
* **Consistency**: The content path in DB must match actual file
  location.  Use checksums to detect corruption.
* **Security**: File permissions restrict direct user access.
* **Scaling**: The hybrid model scales horizontally by storing
  files on network storage and using read replicas for the DB.

This schema should be implemented via migrations.  Future changes
must be accompanied by ADRs and migrations scripts.