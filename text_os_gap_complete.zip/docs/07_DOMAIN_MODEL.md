# Domain Model

This document defines the core domain entities of the Text OS and
their attributes and relationships.  It serves as the blueprint for
database design, API contracts and AI context construction.  All
domain changes must be reflected here and in corresponding ADRs.

## Entities and attributes

### RawText

The immutable source unit of text.  Created through manual entry or
import.

| Field | Type | Description |
| --- | --- | --- |
| `id` | UUID | Unique identifier. |
| `project_id` | UUID | Owning project.  Allows cross‑project references but establishes default context. |
| `content_path` | String | File path on disk to the Markdown file containing the text. |
| `title` | String (nullable) | Optional human title extracted or set by user. |
| `created_at` | Timestamp | When the text was created/imported. |
| `language` | String | ISO code (e.g., `sv`, `en`). |
| `text_type` | Enum | `poem`, `prose`, `note`, `essay`, etc. |
| `tags` | Array of Tag IDs | User tags. |
| `themes` | Array of Theme IDs | AI‑ or user‑derived themes. |
| `origin` | Enum | `manual`, `paste`, `import`, `audio`, `ocr`. |
| `length` | Integer | Number of characters or tokens. |
| `import_job_id` | UUID (nullable) | Link back to the import job that produced it. |

### Draft

An editable version derived from a RawText or another Draft.  Drafts
record differences from their parent and are the target for AI
rewrites.

| Field | Type | Description |
| --- | --- | --- |
| `id` | UUID | Unique identifier. |
| `project_id` | UUID | Owning project. |
| `raw_text_id` | UUID | Origin RawText. |
| `parent_draft_id` | UUID (nullable) | Previous draft in the version chain. |
| `branch_name` | String | Name of the branch; root branch is `main`. |
| `diff` | JSON | Patch object representing changes from parent. |
| `content_path` | String | Path to the full draft content (for convenience; canonical data is diff + raw text). |
| `created_at` | Timestamp | When the draft was created. |
| `status` | Enum | `in_progress`, `frozen`, `archived`. |
| `tags` | Array of Tag IDs | Optional additional tags. |
| `themes` | Array of Theme IDs | Optional themes. |

### BookProject

A container for a publication.  Defines a structure and references
drafts or raw texts.

| Field | Type | Description |
| --- | --- | --- |
| `id` | UUID | Unique identifier. |
| `project_id` | UUID | Owning project. |
| `title` | String | Working title. |
| `subtitle` | String (nullable) | Optional subtitle. |
| `description` | Text (nullable) | Synopsis or elevator pitch. |
| `status` | Enum | `draft`, `in_review`, `finalized`, `archived`. |
| `style_profile_id` | UUID (nullable) | Link to a style profile defining tone and voice. |
| `created_at` | Timestamp | When the book was created. |

### OutlineNode

A hierarchical node defining the structure of a book (part, chapter,
section).  Nodes form a tree.

| Field | Type | Description |
| --- | --- | --- |
| `id` | UUID | Unique identifier. |
| `book_id` | UUID | The book this node belongs to. |
| `parent_id` | UUID (nullable) | Parent node (null for top level). |
| `node_type` | Enum | `book`, `part`, `chapter`, `section`. |
| `title` | String | Title of the node. |
| `index_order` | Integer | Position among siblings. |
| `assigned_texts` | Array of Draft or RawText IDs | References to texts placed in this node. |
| `status` | Enum | `unassigned`, `assigned`, `finalized`, `archived`. |

### Conversation

A chat thread.  Messages reference roles (user or AI) and may refer
to domain objects for context.

| Field | Type | Description |
| --- | --- | --- |
| `id` | UUID | Unique identifier. |
| `project_id` | UUID | Owning project. |
| `context_refs` | Array of ObjectReference | List of objects (raw texts, drafts, book nodes) that define the chat context. |
| `created_at` | Timestamp | When the conversation started. |
| `messages` | Array of Message | Ordered list of messages. |

#### Message (sub‑entity)

| Field | Type | Description |
| --- | --- | --- |
| `id` | UUID | Unique ID. |
| `sender` | Enum | `user`, `assistant`, `system`. |
| `timestamp` | Timestamp | When sent. |
| `content` | Text or JSON | Text body or structured AI output. |
| `applied` | Boolean | Whether an AI suggestion has been applied. |

### Suggestion

AI outputs that represent proposed changes or actions.  A suggestion
is stored separately from messages for accountability and tracking.

| Field | Type | Description |
| --- | --- | --- |
| `id` | UUID | Unique identifier. |
| `conversation_id` | UUID | Conversation where it was produced. |
| `type` | Enum | `analysis`, `rewrite`, `structure`, `next_step`. |
| `input_context` | JSON | References and parameters used to generate the suggestion. |
| `output` | JSON | Structured data representing the suggestion (e.g., diff patch, list of actions). |
| `evidence` | Array of ObjectReference | Text fragments or analyses used to justify the suggestion. |
| `accepted` | Boolean (nullable) | Null until user accepts or rejects. |
| `applied_draft_id` | UUID (nullable) | Draft affected by applying the suggestion. |
| `created_at` | Timestamp | When generated. |

### ImportJob and ExportJob

Jobs representing asynchronous tasks for importing and exporting
content.

| Field | Type | Description |
| --- | --- | --- |
| `id` | UUID | Unique identifier. |
| `project_id` | UUID | Owning project. |
| `type` | Enum | `import`, `export`, `embedding`, `analysis`, etc. |
| `status` | Enum | `pending`, `running`, `completed`, `failed`. |
| `progress` | Float | 0.0–1.0 completion indicator. |
| `error_message` | Text (nullable) | Error details if failed. |
| `input_parameters` | JSON | Parameters used to run the job. |
| `result` | JSON (nullable) | Summary of output; may include file paths or report IDs. |
| `created_at` | Timestamp | When created. |
| `started_at` | Timestamp (nullable) | When job started. |
| `finished_at` | Timestamp (nullable) | When job finished. |

### Tag and Theme

Simple lookup tables used to classify texts.

| Tag Field | Type | Description |
| --- | --- | --- |
| `id` | UUID | Unique identifier. |
| `name` | String | User‑defined label. |
| `description` | Text (nullable) | Optional description. |

| Theme Field | Type | Description |
| --- | --- | --- |
| `id` | UUID | Unique identifier. |
| `name` | String | Normalised concept name (may be multi‑lingual). |
| `source` | Enum | `user`, `AI`. |
| `description` | Text (nullable) | Optional explanation. |

### StyleProfile

A persistent profile capturing stylistic characteristics of a writer
or project.  Profiles enable analysis and comparison.

| Field | Type | Description |
| --- | --- | --- |
| `id` | UUID | Unique identifier. |
| `owner_id` | UUID | Project or user that owns the profile. |
| `name` | String | Profile name. |
| `settings` | JSON | Structured parameters (e.g., average sentence length, vocabulary density, tone descriptors). |
| `created_at` | Timestamp | When profile was created. |
| `last_updated` | Timestamp | Last recalculation time. |

## Relationships summary

* **One project → many objects:** Projects group books, raw texts,
  drafts, conversations, jobs, style profiles, tags and themes.
* **RawText → Drafts:** One raw text can have many drafts.  Drafts
  reference their origin RawText and optional parent Draft.
* **Book → OutlineNodes:** One book has a tree of nodes.  Nodes may
  reference multiple texts.
* **Draft/RawText → Tags/Themes:** Many‑to‑many relationships.
* **Conversation → Messages/Suggestions:** One conversation has
  many messages and suggestions.
* **Jobs → Objects:** Jobs may produce multiple raw texts (import) or
  files (export).  They belong to a project.

## Domain rules

* A RawText cannot be deleted once created.  It may be archived but
  remains available.
* Drafts may be frozen or archived but never silently overwritten.
* A draft may only be applied to one branch; to reuse a draft in
  another branch, create a new branch or version.
* OutlineNodes cannot have cycles; the tree must be acyclic.
* Tag names are unique per project; theme names are normalised
  across projects.
* Jobs must transition through status states in order (pending →
  running → completed/failed).

Further state transitions and lifecycles are documented in
`docs/08_OBJECT_STATES_AND_LIFECYCLES.md`.