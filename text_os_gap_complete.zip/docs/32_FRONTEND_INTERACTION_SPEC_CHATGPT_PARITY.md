# Frontend Interaction Spec: ChatGPT-Parity + Text-Object Depth

This document raises the frontend specification from architectural level
to **interaction level**. The goal is not visual cloning. The goal is to
achieve the same degree of smoothness, clarity and low-friction dialogue
that users expect from ChatGPT, while binding that experience deeply to
texts, drafts and books.

## Locked decisions

- The primary UX center is a **conversation-first writing workspace**,
  not a dashboard.
- The system must support **editor-only**, **chat-only**, and
  **split-view** modes.
- Chat must feel immediate and calm:
  - fast composer response
  - visible streaming
  - clear context
  - low UI noise
- Suggestions must be actionable **inside the same surface** without
  navigation jumps wherever possible.
- Text objects, not generic documents, are the UI’s semantic core.

## Core desktop layouts

### Layout A — Chat-first workspace

Use when entering from a project conversation or book conversation.

```text
┌────────────────────────────────────────────────────────────────────────────┐
│ topbar: project / book / global search / status / profile                 │
├───────────────┬──────────────────────────────────────────────┬─────────────┤
│ left rail     │ main conversation column                     │ right rail  │
│ projects      │ messages                                     │ context     │
│ books         │ suggestion cards                             │ evidence    │
│ texts         │ composer                                     │ versions    │
│ collections   │                                              │ actions     │
└───────────────┴──────────────────────────────────────────────┴─────────────┘
```

### Layout B — Editor-first split workspace

Use when entering from a draft or raw text.

```text
┌────────────────────────────────────────────────────────────────────────────┐
│ topbar                                                                     │
├───────────────┬───────────────────────────────┬────────────────────────────┤
│ left rail     │ editor column                 │ chat / suggestions column  │
│               │ content                       │ active conversation        │
│               │ inline comments               │ streaming replies          │
│               │ selection tools               │ apply / ignore controls    │
└───────────────┴───────────────────────────────┴────────────────────────────┘
```

### Layout C — Book structure workspace

Use when entering from a book.

```text
┌────────────────────────────────────────────────────────────────────────────┐
│ topbar                                                                     │
├───────────────┬───────────────────────────────┬────────────────────────────┤
│ left rail     │ outline / chapter cards       │ editor or chat context     │
│               │ drag / reorder                │ selected node details      │
│               │ structural alerts             │ node-specific AI actions   │
└───────────────┴───────────────────────────────┴────────────────────────────┘
```

## Message stream behavior

The message stream must behave with ChatGPT-like clarity:

- newest messages anchored toward the bottom
- auto-scroll only while the user is already near bottom
- if the user has scrolled up, show “Jump to latest” instead of forcing
  movement
- stream assistant output token-by-token or chunk-by-chunk
- while streaming, keep the composer usable unless the operation is
  blocking by design
- preserve exact message history ordering; no silent reordering of cards

## Composer behavior

The composer is a first-class input surface.

### Composer states

| State | Trigger | Behavior |
| --- | --- | --- |
| idle | no active typing | placeholder reflects current context |
| typing | user enters text | submit enabled when meaningful input exists |
| sending | user submits | input locks only briefly until request accepted |
| streaming | assistant is responding | composer remains available for stop/follow-up unless request type forbids |
| blocked | cost limit / missing context / invalid state | clear reason shown above composer |

### Composer rules

- `Enter` sends.
- `Shift+Enter` inserts newline.
- drag-and-drop onto composer attaches text objects or files.
- slash commands open a lightweight command menu:
  - `/rewrite`
  - `/analyze`
  - `/outline`
  - `/themes`
  - `/next`
  - `/compare`
- context pills appear above the composer and are removable.

### Placeholder examples

- project chat: `Ask about this project, its themes, or what to do next`
- draft chat: `Ask about this draft, selected passage, or request a rewrite`
- book chat: `Ask about structure, chapter flow, gaps, or outline ideas`

## Context visibility

A major difference from generic chat tools is that Text OS must make
context explicit.

### Required context indicators

- current project name
- current object type:
  - Raw Text
  - Draft
  - Book
  - Outline Node
  - Multi-text context
- selected text range when relevant
- pinned context items count and labels
- retrieval status:
  - no retrieved context
  - retrieved context added
  - retrieved context trimmed to fit budget

### Context drawer

A context drawer opens from the right and shows:

- all pinned objects
- retrieved fragments
- style profile in effect
- canonical rules in effect
- estimated token load
- remove / reorder controls

The user must always be able to inspect “what the model saw.”

## Suggestion card anatomy

Suggestion cards must be visually distinct from plain assistant prose.

### Card types

- rewrite card
- analysis card
- next-step card
- outline-change card
- compare card
- continuity warning card

### Card structure

```text
header: suggestion type + confidence / status
body: structured recommendation
evidence: linked references to texts / passages
actions: apply | apply to branch | ignore | save for later | inspect diff
footer: model used / timestamp / context note
```

### Required behaviors

- apply must not navigate away unexpectedly
- ignore must not delete the card from history; it only changes status
- save for later places the card into a review queue
- expired cards show a visible expired badge with reason

## Rewrite preview interaction

For rewrite suggestions, the preview must support:

- inline diff
- side-by-side diff
- original-only toggle
- suggested-only toggle
- “apply to current draft”
- “apply to new branch”
- “copy suggestion only”

The system must never force a rewrite into the draft without explicit
user choice.

## Selection-to-chat flow

This interaction must be extremely low friction.

1. user selects text in editor
2. mini action popover appears
3. actions:
   - Ask AI
   - Rewrite
   - Analyze
   - Add comment
   - Pin to chat
4. if the user chooses Ask AI / Rewrite / Analyze:
   - the selected range becomes a visible context pill in chat
   - the chat pane opens or focuses
   - the composer is pre-seeded with a suitable prompt template
   - the user can edit before sending

## Split-view mechanics

The split view must feel stable, not twitchy.

- divider drag resizes panels
- user preferences persist per mode
- minimum readable widths enforced
- if width falls below threshold, switch to tabbed mode instead of
  crushing both panels
- panel state persists across reloads:
  - editor/chat ratio
  - right rail open/closed
  - active tab

## Keyboard-driven workflow

The product should be efficient for serious writers.

### Minimum shortcuts

| Shortcut | Action |
| --- | --- |
| `Ctrl/Cmd + K` | global search / command palette |
| `Ctrl/Cmd + Shift + N` | quick capture |
| `Ctrl/Cmd + S` | force save snapshot |
| `Ctrl/Cmd + Enter` | apply focused suggestion when applicable |
| `Alt + 1/2/3` | switch between editor / chat / outline |
| `Ctrl/Cmd + /` | focus composer |
| `Esc` | close drawer / cancel transient UI |
| `Ctrl/Cmd + Shift + B` | create branch |
| `Ctrl/Cmd + Shift + D` | compare versions |

## Streaming and latency handling

The UI must distinguish between:

- request accepted
- model thinking
- response streaming
- post-processing / parsing
- action-ready state

### Feedback model

- immediate spinner in composer after send
- streaming placeholder appears in message list within ~100–300 ms
- if structured parsing takes longer, show:
  - `Generating response...`
  - then `Preparing actionable cards...`
- never leave the user in silent waiting state

## Error interaction design

Errors must be contextual and recoverable.

### Examples

- `This suggestion can no longer be applied because the draft changed.`
  Actions: refresh context / regenerate suggestion
- `This request exceeds your current budget threshold.`
  Actions: continue anyway / switch to lower-cost mode / cancel
- `Provider timeout.`
  Actions: retry / switch model / save prompt as pending

## Mobile interaction model

Mobile does not mirror desktop one-to-one.

### Principles

- one primary pane at a time
- composer always reachable
- object context always visible in compact header
- bottom sheet for suggestion actions
- swipe between:
  - editor
  - chat
  - structure
- long-press on selected text opens action sheet

### Mobile-specific rules

- avoid persistent three-column layouts
- reduce simultaneous metadata display
- defer heavy diff views into dedicated full-screen modal
- use sticky apply bar for suggestion review

## Visual tone

The UI should feel:

- calm
- premium
- literate
- tool-like, not gamified
- less “productivity dashboard”, more “serious writing instrument”

That implies:

- low ornamentation
- strong typography hierarchy
- generous whitespace in main conversation/editor columns
- restrained color usage
- obvious but not flashy action states

## Component inventory

Core components that must exist:

- AppShell
- ProjectTree
- BookOutlineTree
- EditorSurface
- CommentRail
- ConversationStream
- Composer
- ContextPillBar
- SuggestionCard
- DiffPreview
- EvidencePanel
- RightRailInspector
- CommandPalette
- JobToastCenter
- EmptyStateBlock
- ErrorStateBlock

## Risks / trade-offs

- pushing too hard toward ChatGPT familiarity can erase the identity of
  the product as a serious writing system
- pushing too hard toward structural complexity can make chat feel heavy
- split view is powerful but easy to overcomplicate
- suggestion cards that are too dense will feel enterprise-heavy rather
  than elegant

## Acceptance criteria

The interaction model is considered good enough when:

- a new user can start a project, open a draft, ask for a rewrite and
  apply it without training
- an experienced user can stay on keyboard for the majority of a writing
  session
- context is always inspectable before expensive AI calls
- suggestion application feels reversible and safe
- the chat feels fast and clear even when the underlying system is more
  structured than generic AI chat
