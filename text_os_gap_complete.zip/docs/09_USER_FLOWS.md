# User Flows

User flows illustrate how a person interacts with the Text OS to
accomplish high‑level tasks.  These narratives link the domain
model to UI behaviours and API calls.  They are not UI mockups but
step‑by‑step sequences that should be validated through testing.

## Flow 1: Capturing and classifying a new idea

**Goal:** A user records a sudden thought and ensures it is stored
with appropriate metadata for later use.

1. **Quick capture:** From anywhere in the app, the user invokes
   the quick‑capture overlay (keyboard shortcut or button).  A small
   editor appears.
2. **Enter text:** The user types or pastes their idea.  The overlay
   suggests a title based on the first sentence but allows editing.
3. **Select project:** The user chooses the project (defaults to
   “Inbox” project).  Optionally assign tags and text type.
4. **Save:** On Save, the system creates a RawText with `status =
   Imported`, stores the content on disk and writes metadata to the
   database.  Language and type detection run asynchronously.
5. **Confirmation:** A toast message confirms the capture and shows
   the assigned language/type.  The overlay clears for reuse.

## Flow 2: Reviewing and rewriting a draft with AI assistance

**Goal:** A user refines an existing draft using AI suggestions.

1. **Open draft:** The user navigates to a draft via the project
   tree.  The editor loads the content and version history.
2. **Select passage:** The user highlights a paragraph and clicks
   “Rewrite” in the editor toolbar.
3. **Choose rewrite type:** A modal presents options: shorten,
   expand, clarify, tone shift.  The user selects “clarify”.
4. **AI call:** The system builds context including the selected
   passage, the parent raw text, style profile (if any) and sends a
   prompt to the AI model via the orchestration layer.
5. **Preview suggestion:** The AI returns a diff patch.  The modal
   shows the original and suggested text side by side with changes
   highlighted.  The user may toggle between diff and plain view.
6. **User decision:** The user clicks “Apply” or “Ignore”.  On
   apply, a new draft version is created with the diff; the state
   remains `in_progress`.  The suggestion is marked as applied.  On
   ignore, the suggestion is marked as ignored and the draft remains
   unchanged.
7. **Audit log:** The suggestion, context and outcome are recorded
   in the audit log for later review.

## Flow 3: Creating and populating a book project

**Goal:** A user begins assembling a book from existing drafts.

1. **Create book:** From the project menu, the user selects
   “New Book”.  A modal requests a title, optional subtitle and
   description.  The book is created in `draft` state with an empty
   outline root.
2. **Define outline:** In the book workspace, the user adds parts,
   chapters and sections via a tree editor.  Nodes are initially
   `unassigned`.
3. **Assign texts:** For each chapter, the user drags one or more
   drafts from the project tree into the chapter node.  The system
   sets the node state to `assigned` and records the assignment.
4. **Generate TOC:** Clicking “Generate TOC” produces a preview of
   the table of contents.  The user can adjust titles and order.
5. **Review structure:** The user asks the AI for a structural
   analysis via the chat panel.  The AI examines the outline,
   highlights gaps (e.g., empty chapters) and suggests ordering
   changes.  Suggestions appear in a structured card with accept
   buttons.  Applying a suggestion rearranges nodes or flags
   chapters for further writing.
6. **Export:** Once the user is satisfied, they click “Export
   Book”.  The system checks that all nodes are at least `assigned`
   and assembles a single Markdown file.  The book remains in
   `draft` state until finalised.

## Flow 4: Semantic search and context assembly

**Goal:** A user finds related fragments to include in a new poem.

1. **Select query:** From the editor, the user highlights a line
   and clicks “Find similar”.
2. **Retrieve context:** The system embeds the selected text and
   queries the semantic index within the current project.  It
   retrieves the top N similar fragments along with similarity
   scores.
3. **Display results:** Results appear in a side panel, grouped by
   document.  Each result shows a snippet with highlighted matches
   and a link to open the original text.
4. **Add to context:** The user may add selected results to a
   temporary context collection for an AI conversation or drag them
   into a draft.
5. **AI call:** When the user asks the AI to write a transition
   passage, the system includes the temporary context in the prompt.

## Flow 5: Importing a manuscript from an external source

**Goal:** Henrik imports a 200‑page docx file and prepares it for
analysis.

1. **Select file:** In the ingestion panel, Henrik clicks “Import
   file” and chooses the docx.
2. **Start import job:** The system creates an ImportJob with
   `status = pending`.  The background worker picks it up and
   processes the docx: parsing text, splitting into RawTexts (e.g.,
   per chapter), detecting language and type, extracting metadata.
3. **Monitor progress:** Henrik sees the job progress bar.  When
   finished, the ImportJob status moves to `completed`.  Any errors
   appear in the log.
4. **Review imported texts:** The new raw texts appear in the
   project’s “Raw Texts” list.  Henrik can then proceed to organise,
   tag and analyse them.

## Flow 6: Applying AI suggestions safely

**Goal:** Reinforce the explicit apply invariant.

1. **View suggestion:** In a conversation, the AI proposes moving
   text B before text A in a chapter.  The suggestion card
   includes context and evidence.
2. **Preview diff:** Clicking “Preview” shows a diff of the chapter
   before and after the move.  The user can adjust if necessary.
3. **Apply:** The user clicks “Apply” to accept.  The system
   creates a new version of the chapter draft reflecting the change.
   The suggestion record is marked as applied.
4. **Ignore:** Alternatively, the user clicks “Ignore”.  The
   suggestion is recorded as ignored and no changes occur.
5. **Review later:** Ignored suggestions remain accessible in the
   conversation and decision log.  They can be revisited and
   applied if still valid.

## Notes

These flows are illustrative; real workflows may vary.  They should
be used to design UI prototypes and test cases.  They also hint at
necessary API endpoints, event triggers and data transformations.