# Import, Capture and Ingestion

Capturing incoming text is the first step in the Text OS.  This
document describes the mechanisms for manual entry, file import and
media ingestion.  It covers the import queue, normalisation,
deduplication and provenance tracking.

## Capture interfaces

### Quick capture overlay

* Accessible from any view via a shortcut (`Ctrl+Shift+N`).
* Minimal UI with a multi‑line text box, title field and project
  selector.
* Detects and suggests language and text type on the fly.
* Supports offline caching; unsaved entries persist until submitted.

### Paste/drop import

* Users can paste text into the editor or drop a text file onto the
  workspace.  If the file is small (<100 KB), it opens directly as
  a RawText after confirmation.

### File import (bulk)

* Users select one or more files via the import dialog.  Supported
  formats (MVP): `.txt`, `.md`.  Future (P1) formats: `.docx`, `.pdf`,
  `.epub`, `.html`.
* The system uploads files to a temporary staging area and creates
  an `import` job per batch.  The user sees the job progress.
* For each file, the processor detects encoding, splits into
  logical units (chapters/paragraphs), extracts metadata and
  creates RawTexts.

### Audio and image ingestion (P1)

* Users upload audio or image files via the ingestion dialog.
* The system creates a job that calls external services (e.g., Whisper
  for transcription, OCR API).  Transcripts are saved as RawTexts
  with the `origin` marked accordingly.  Time codes or bounding box
  data are stored in metadata for potential alignment.

## Import queue and review

The import pipeline uses a queue to handle large batches without
blocking the UI.  Imported texts may need review:

1. **Pending list:** After processing, new RawTexts appear in a
   “Pending Review” list.  They are not yet included in search or AI
   until reviewed.
2. **Review screen:** Shows extracted metadata (language, type,
   suggested title, tags).  The user can edit these fields.
3. **Confirmation:** On confirm, the text moves to the project’s
   Raw Texts list and triggers embedding jobs.  If the user discards
   the text, it is archived.

## Normalisation

Imported texts may have inconsistent whitespace, encoding or line
breaks.  The normalisation stage performs:

* **Unicode normalisation** (e.g., NFC) to standardise diacritics.
* **Line ending conversion** to LF.
* **Whitespace trimming** at start/end of file and deduplicating
  multiple blank lines.
* **Preserve original formatting**: do not reflow paragraphs.
* **Metadata extraction**: attempt to detect titles, headings,
  front matter (for docx), and creation dates.

Normalisation scripts must be deterministic and idempotent.

## Deduplication and similarity

To avoid clutter and unnecessary cost, the system must detect when
an imported text is a duplicate or near‑duplicate of existing
content:

* **Content hash**: compute a hash (e.g., SHA‑256) of the cleaned
  text.  Exact matches are flagged as duplicates.
* **Locality‑sensitive hashing**: for near‑duplicates, compute a
  MinHash or similar fingerprint.  If similarity exceeds a threshold
  (e.g., >95%), mark as potential duplicate and prompt the user to
  link or discard.
* **User control**: The user decides whether to create a new text
  anyway or reference the existing one.

## Provenance and origin

Each RawText records an `origin` field and optionally a
`source_path` (file path, URL).  This ensures that provenance is
tracked.  For imported files, the system stores the original file in
object storage (unless deleted after processing) and links the
RawText to the corresponding ImportJob.

## Error handling

Common errors during import include unsupported formats, encoding
issues and corrupted files.  The import job catches exceptions and
records `error_message`.  The UI displays an error summary at the end
of the job with options to retry or download error logs for
troubleshooting.

## Security considerations

* **Sanitisation:** Incoming text may contain malicious content
  (e.g., scripts).  The importer must strip or escape HTML before
  saving to Markdown.
* **Permissions:** Files are processed under the authenticated
  user’s context.  Users cannot import files into projects they do
  not own.
* **Data retention:** Original imported files may contain sensitive
  information.  Provide an option to delete the originals after
  processing.

Effective capture and import procedures ensure that the system
receives clean, deduplicated and well‑annotated texts ready for
organisation and analysis.