# ADR‑004: Context Assembly

## Status

Accepted – 2026‑04‑20

## Context

LLMs rely on context to generate relevant responses.  Without a
deterministic method to select context, the model may hallucinate or
miss important information.  We considered:

1. **Magic memory**: Feed the entire project archive to the model.
   Pros: simplicity.  Cons: high cost, context length limits,
   unpredictable outputs.
2. **Manual selection**: Users manually add all context.  Pros:
   absolute control.  Cons: burdensome; risk of forgetting relevant
   fragments.
3. **Retrieval‑based assembly**: Combine user‑pinned context,
   current text and retrieval results (FTS + semantic search) into a
   deterministic set of fragments.

## Decision

Implement **deterministic retrieval‑based context assembly**:

* Start with explicit context (current draft/raw text and pinned
  items).
* Use full‑text and semantic search to retrieve relevant fragments.
* Apply ranking and filtering rules to select a bounded number of
  fragments.  Ranking criteria include similarity, recency and
  user‑defined weights.
* Assemble the prompt in a deterministic order (e.g., by document
  ID and position).  The same input yields the same context.
* Log the context used for each AI call.

## Rationale

* Ensures reproducibility and debuggability.  If a user questions an
  AI suggestion, we can trace the exact context used.
* Prevents the model from inventing facts outside the provided
  fragments, reducing hallucination.
* Balances user control and automation: users can pin critical
  context, while retrieval covers what they might miss.

## Consequences

* Requires implementing retrieval pipelines and ranking logic.
* Some relevant context may be omitted if ranking is imperfect; this
  can be mitigated by adjustable parameters and user feedback.
* Logging context increases storage requirements but is necessary for
  auditing.