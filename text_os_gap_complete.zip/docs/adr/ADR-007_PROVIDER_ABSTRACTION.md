# ADR‑007: Provider Abstraction

## Status

Accepted – 2026‑04‑20

## Context

AI functionality is delivered via external APIs.  OpenAI is the
initial provider, but dependency on a single provider may pose risks
(pricing changes, terms of service, service outages).  Options:

1. **Tightly coupled provider**: Hard‑code calls to a single
   provider’s API in the business logic.  Simple but brittle.
2. **Generic provider interface**: Define an abstraction layer with
   methods like `generate`, `embed`, `transcribe`, `moderate`.  Each
   provider implements the interface.

## Decision

Introduce a **provider abstraction layer**.  The orchestration
module calls high‑level methods (`generate`, `embed`, `transcribe`),
which are implemented by provider adapters (e.g., OpenAIAdapter,
LocalLLMAdapter).  Provider selection is configured per task.

## Rationale

* Reduces vendor lock‑in; we can switch providers or add local
  models without changing application logic.
* Enables fallback: if the primary provider fails, the system can
  route to a secondary provider.  Users can choose providers that
  match privacy or cost requirements.
* Supports policy enforcement (e.g., PII redaction) within the
  adapter.

## Consequences

* Slightly more code complexity; maintain multiple adapters.
* Must define a common set of capabilities and map provider
  responses to our structured output schemas.
* Provider differences (e.g., max tokens, model features) must be
  handled gracefully by orchestration logic.