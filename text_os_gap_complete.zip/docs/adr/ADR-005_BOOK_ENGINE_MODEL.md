# ADR‑005: Book Engine Model

## Status

Accepted – 2026‑04‑20

## Context

We need a model to represent books within the Text OS.  Options
evaluated:

1. **Flat collection**: A book is just an ordered list of texts.  No
   hierarchy.  Easy to implement but insufficient for complex
   structures (parts, chapters, sections).
2. **Nested documents**: Represent books as a single document with
   Markdown headings.  Pros: simple export.  Cons: limited
   flexibility; difficult to assign multiple drafts to one section.
3. **Outline tree**: Use a separate tree of nodes (parts, chapters,
   sections) that reference texts.  Supports multiple levels,
   reordering and assignments.

## Decision

Adopt the **outline tree model** for books.  Each BookProject has a
tree of OutlineNodes.  Nodes define structure and contain references
to drafts or raw texts.  Nodes have `node_type`, `title` and
`index_order`.  Assignments are many‑to‑many with order within the
node.

## Rationale

* Hierarchical structure mirrors how readers navigate books and how
  authors think about composition.
* Supports templates and variations: different book types can
  predefine certain node patterns.
* Enables AI assistance: the model can reason about empty chapters,
  redundancy and flow.
* Aligns with our principle that book structure is a layer above
  texts, preserving the underlying drafts.

## Consequences

* Implementation complexity: must build UI for tree editing and
  maintain mapping tables.
* Export logic must traverse the tree and insert texts in order.
* Reusing drafts across nodes requires careful handling to avoid
  duplication or inconsistency.