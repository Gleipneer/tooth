# ADR‑001: Product Shape

## Status

Accepted – 2026‑04‑20

## Context

The team must decide how to conceptualise and scope the Text OS.  Two
broad options were considered:

1. **Incremental plugin**: Extend an existing editor (e.g., Obsidian,
   VS Code) with AI features.  This approach leverages an existing
   ecosystem but inherits constraints and may fragment the user
   experience.
2. **Standalone system**: Build a dedicated application designed
   around a domain model for texts, drafts, books and conversations.
   This allows tight integration, fine‑grained control and the
   ability to enforce invariants.

## Decision

We will build the Text OS as a **standalone system** designed from
scratch.  The core is a domain model capturing raw texts, drafts,
books and conversations.  The UI combines an editor, chat and
organisation tools in a single application.  AI orchestration is
tightly integrated, and all content is stored in a format that
prioritises portability and immutability.

## Rationale

* A standalone system allows us to design the information
  architecture and user flows optimised for creative writing.
* It supports the principle of **editor‑first** experience with
  integrated chat rather than bolting features onto an existing
  general‑purpose editor.
* It enables us to enforce critical invariants (immutable raw text,
  explicit apply) without interference from external tool
  behaviours.
* It simplifies support and onboarding because the entire stack is
  controlled.

## Consequences

* Requires building more infrastructure (authentication, UI) but
  yields long‑term flexibility.
* May initially lack some ecosystem plugins; integration via import
 /export and API can mitigate this.
* Users must adopt a new tool rather than a familiar editor.  Good
  design and migration/import features are essential.