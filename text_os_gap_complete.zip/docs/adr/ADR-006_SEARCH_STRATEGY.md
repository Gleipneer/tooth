# ADR‑006: Search Strategy

## Status

Accepted – 2026‑04‑20

## Context

Users need to find relevant text quickly and reliably.  Options for
search include:

1. **Full‑text search only**: Use the database’s built‑in FTS.
   Simple and fast but poor at capturing semantic similarity.
2. **Semantic search only**: Use embeddings and vector similarity.
   Captures semantics but loses precise keyword matching and
   filtering.
3. **Hybrid search**: Combine full‑text and semantic search with
   ranking heuristics.

## Decision

Implement **hybrid search**: index texts both in full‑text and
vector form.  Search queries can use either or both modes.  The
retrieval pipeline will merge results using configurable weights and
filters.  Semantic search is limited to the current project in MVP,
with cross‑project support later.

## Rationale

* Keyword search remains valuable for precision and for languages
  where embeddings may be weak.
* Semantic search provides insight into theme and concept similarity
  critical for context assembly and inspiration.
* Combining both yields better recall and precision.  Tuning weights
  is possible based on usage patterns.

## Consequences

* Increased complexity: maintain both FTS and vector indexes.  Need
  to keep embeddings updated on new texts.
* Additional cost for embedding generation.  Mitigated by batching
  and using affordable embedding models.
* Ranking heuristics require experimentation and may need user
  exposure to adjust weights in the future.