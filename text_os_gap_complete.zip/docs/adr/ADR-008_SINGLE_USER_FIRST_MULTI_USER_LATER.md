# ADR‑008: Single User First, Multi‑User Later

## Status

Accepted – 2026‑04‑20

## Context

The team debated whether to support multiple users in the initial
release.  Multi‑user support introduces permissions, collaboration
and data partitioning complexities.  Options:

1. **Multi‑user from the start**: Build the system with robust
   permission models, role assignments and collaborative editing.
   Pros: ready for teams; no need for later migration.  Cons: high
   complexity, delays MVP.
2. **Single user**: Target individual authors.  Defer multi‑user
   features.  Pros: focus on core value; simpler.  Cons: requires
   redesign to add users later.

## Decision

Start with **single user** per instance.  All objects are owned by
the authenticated user.  Implement user ID fields and a basic
permission model in the database, but do not expose roles in the UI.
Define an extension path to multi‑user mode via ADRs and roadmap.

## Rationale

* Simpler to deliver and test with a small team of writers.
* Avoids building complex collaborative editing and conflict
  resolution before core functions prove their value.
* Still enables future multi‑user support because the schema
  includes user IDs and we design permissions conceptually.
* Allows focusing on the quality of the AI and writing experience.

## Consequences

* Some features (e.g., sharing a book with an editor) are deferred.
* Later introduction of multi‑user support will require API and UI
  changes, but the foundational support (user IDs, roles table) is
  present.
* The MVP should avoid hard‑coding assumptions about a single user
  in the domain logic.  Always reference `project.owner_id` or
  similar to facilitate expansion.