# ADR‑003: AI Write Boundaries

## Status

Accepted – 2026‑04‑20

## Context

AI models can suggest changes to user texts.  Without clear
boundaries, AI might modify content without user consent, leading to
loss of original work or unwanted stylistic shifts.  The system must
define how AI interacts with canonical texts.

## Decision

* **AI is advisory**: AI suggestions are separated from canonical
  texts.  They are stored as suggestion records with structured
  outputs (diffs, recommended actions) and evidence citations.
* **Explicit apply**: Suggestions are never applied automatically.
  The user must explicitly apply or ignore each suggestion.  Apply
  creates a new draft version or structural change.
* **Immutable originals**: Raw texts are never modified.  AI may
  suggest rewrites, but the original remains untouched.
* **Expired suggestions**: If the underlying text changes, existing
  suggestions expire and cannot be applied.  The user must request
  a new analysis.

## Rationale

* Upholds user control and trust.  Writers must decide whether to
  accept AI edits.
* Supports auditability: suggestions, their context and outcomes are
  recorded.
* Reduces risk of AI “runaway” behaviour that overwrites user data.

## Consequences

* Additional UI complexity: suggestions need preview, apply and
  ignore buttons.
* Slower workflows for users who prefer automatic changes; however
  this is intentional for safety.
* Requires version management: applying suggestions creates new
  versions, increasing storage usage.  This cost is acceptable
  because drafts are lightweight (diffs).