# ADR‑002: Storage Strategy

## Status

Accepted – 2026‑04‑20

## Context

We must choose how to store user texts and metadata.  Options:

1. **Database‑only**: Store text content and metadata entirely in
   PostgreSQL.  Pros: single storage layer, transactional.  Cons:
   performance issues with large blobs, less portable.
2. **File‑only**: Store everything as files.  Pros: simple, easy to
   back up.  Cons: difficult to query, no ACID transactions.
3. **Hybrid**: Store canonical text content in the filesystem and
   store metadata, diffs and relationships in a relational database.

## Decision

Adopt a **hybrid storage strategy**: store canonical text content
as Markdown files on disk and store metadata, relationships and
diffs in PostgreSQL.  Embeddings are stored in a vector index.

## Rationale

* Text files remain readable without the system and can be version
  controlled separately.  Users can back them up easily.
* Metadata and relationships benefit from relational querying.
* Allows atomic transactions: file write followed by DB insert.
* Separation of canonical vs. derived data (embeddings) supports
  reproducibility.

## Consequences

* Implementers must handle synchronisation between the filesystem
  and database.  File writes need to be atomic; missing files must
  be detected.
* Backups must include both DB and files.  Snapshot tooling must
  ensure consistency.
* Scalability: storing many files requires careful organisation and
  may need object storage for growth.