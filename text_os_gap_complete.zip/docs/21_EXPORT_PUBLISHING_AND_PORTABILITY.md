# Export, Publishing and Portability

The Text OS emphasises ownership of content and freedom to take
one’s work elsewhere.  This document covers export formats,
publishing options and strategies for portability and backup.

## Export formats

During the MVP, export focuses on Markdown and plain text.  Post‑MVP
adds richer formats.

### Markdown (P0)

* Generates a `.md` file containing front matter, outline headings
  (with `#`, `##`), inserted drafts, and optional metadata
  comments.
* Includes internal anchors for sections.  Footnotes and endnotes
  supported via standard Markdown syntax.
* Suitable for import into other editors or static site generators.

### Plain text (P0)

* Strips Markdown syntax and outputs a `.txt` file.  Useful for
  reading in simple editors or posting online.  Loses structural
  hierarchy; the user can reformat externally.

### EPUB and PDF (P1)

* Uses a typesetting library (e.g., Pandoc, Calibre) to convert
  Markdown into EPUB and PDF.  Applies a default style sheet.
* Generates a cover page if provided by the user.
* Embeds table of contents with links.
* Exports support metadata fields (author, publisher, ISBN).  These
  fields must be provided or left blank.

### Other formats (P2)

* **DOCX** for interoperability with word processors.
* **HTML** for web publishing.
* **RDF/XML** for archival projects.

## Publishing considerations

The system itself does not publish content to the public web or
marketplaces.  Instead, it focuses on producing high‑quality output
that can be used in downstream publishing workflows.  However:

* Provide export templates that match typical publishing guidelines
  (e.g., poetry layout vs. essay layout).
* Document how to import the exported files into popular tools
  (e.g., InDesign, Vellum).
* Consider adding integration with third‑party publishing platforms
  (Amazon KDP, Leanpub) as a P2 feature.  Integrations require
  separate authentication and careful handling of rights and revenue.

## Portability pack

To ensure long‑term ownership, the system can produce a **portability
pack**: a ZIP archive containing:

* All raw text files (`raw/*.md`).
* All draft files (`drafts/*.md`).
* All books and outlines (`books/*.json`).
* Metadata export (`metadata/*.json`), including projects,
  tags/themes, assignments, style profiles, decision logs.
* A README explaining the structure and how to restore it.

The portability pack can be imported into another instance of the
Text OS or other systems through conversion scripts.  The export
job’s result includes a manifest with checksums for integrity.

## Backup and restore

Providing reliable backup and restore ensures users do not lose
their work:

* **Manual backup**: Users can download a snapshot of the database
  dump and all text files.  The system prepares an archive and
  provides a download link.  Backups include encryption if enabled.
* **Scheduled backups**: The system can perform scheduled backups
  (e.g., weekly) and store them in user‑provided object storage.
  Users configure retention periods.
* **Restore process**: To restore, the user provides the backup
  archive; the system creates a new instance (or overwrites the
  current one if allowed), restoring the database and unpacking
  files.  Users should be warned that restore will overwrite
  existing data.

## Import/export parity

Where possible, exported content should be importable back into the
system without loss.  For example, importing a previously exported
book should recreate the book’s outline and assigned drafts.  This
requires embedding metadata (IDs, relationships) in the exported
files or manifest.

## Data exit strategy

If a user decides to stop using the Text OS, the system should:

* Provide a complete export and portability pack.
* Provide documentation or scripts to convert the data into
  standards (e.g., MARC for libraries, TEI XML for scholarly work).
* Confirm deletion of the user’s data after export, subject to
  retention policy and legal requirements.

## Legal and ethical considerations

* Ensure that exported content does not include copyrighted
  material owned by others without permission.
* When integrating with publishing platforms, respect their terms
  and guidelines (e.g., content quality standards, prohibited
  content).
* Provide warnings about privacy if texts contain personally
  identifiable information; the system cannot guarantee removal of
  such information in exported documents.

By prioritising export and portability, the Text OS aligns with
user ownership and avoids vendor lock‑in.