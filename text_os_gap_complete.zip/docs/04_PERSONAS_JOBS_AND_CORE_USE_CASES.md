# Personas, Jobs and Core Use Cases

Understanding who we are building for and what problems they face is
critical to shaping the Text OS.  This document describes the
archetypal users, their jobs‑to‑be‑done, and the core scenarios the
system must support.  These personas are illustrative but grounded
enough to inform design decisions.

## Primary persona: The Prolific Writer

**Name:** Lisa

**Profile:** A 35‑year‑old Swedish poet and essayist.  Lisa writes
hundreds of fragments—poems, reflections, journal entries—each
month.  She keeps digital and analogue notes but lacks a unified
system.  She is comfortable with technology but values autonomy and
creative control.

**Jobs‑to‑be‑done:**

1. **Capture inspiration** quickly without losing ideas.  She
   sometimes dictates verses on her phone or scribbles on paper and
   wants those fragments consolidated.
2. **Organise an ever‑growing corpus** of texts.  She needs to tag
   and group pieces by theme, project or motif.
3. **Experiment and refine** her texts.  Lisa rewrites extensively,
   trying different rhythms and tones.  She needs safe branching and
   diffing.
4. **Construct books from fragments.**  When she decides to publish
   a collection, she must assemble the right pieces into a coherent
   structure.
5. **Engage with AI as an assistant**, not a co‑author.  She
   appreciates suggestions on structure, clarity and style but insists
   on making the final call.

**Pain points:**

- Fragmentation: notes scattered across files and devices.
- Loss of context: forgetting why she wrote something or how it
  connects to other texts.
- Structural overwhelm: turning fragments into a book is
  time‑consuming and requires macro‑level thinking.
- Distrust of AI: fear that AI might change her voice or overtake her
  creative process.

**Motivations:**

- Produce high‑quality work efficiently while preserving artistic
  integrity.
- Build a sustainable archive that she can mine for future projects.
- Experiment safely with new styles and structures.

## Secondary persona: The Editor/Researcher

**Name:** Henrik

**Profile:** A 48‑year‑old editor at a small publishing house.  He
receives manuscripts and loose text collections from authors and must
help shape them into coherent books.  Henrik uses the Text OS to
analyse submissions, identify recurring themes and structural gaps,
and propose editing plans.

**Jobs‑to‑be‑done:**

1. **Import and organise** large bodies of text from different
   authors quickly.
2. **Assess manuscripts** for thematic coherence and identify
   redundancies or contradictions.
3. **Create outlines** and propose structural edits.
4. **Communicate suggestions** back to the author in a structured
   way with supporting evidence.
5. **Track editorial decisions** and maintain a record of changes.

Henrik is secondary because the first version of the product targets
individual creators.  However, his needs influence longer‑term plans
for multi‑user and collaborative workflows.

## Future persona: The Aspiring Writer

This persona represents students or hobbyists exploring creative
writing.  They have fewer texts but require more guidance and
education on craft.  They may rely heavily on AI for suggestions
and may expect more templated help.  Supporting them will require
curated tutorials and simplified workflows and is therefore a
post‑MVP consideration.

## Jobs‑to‑be‑done summary

The table below summarises core jobs and links them to functional
domains in the system.  A job may span multiple domains; the
priority reflects the MVP emphasis.

| Job | Description | Domains | Priority |
| --- | ----------- | ------- | ------- |
| Capture inspiration | Rapidly record raw text via typing or dictation and store it with minimal friction. | Capture, Storage | P0 |
| Organise corpus | Tag, group, classify and filter texts across projects, themes, dates. | Organisation, Search | P0 |
| Rewrite and refine | Edit texts and compare versions safely using AI suggestions or manual operations. | Editor, AI orchestration | P0 |
| Build a book | Create a book project, design an outline and map texts into chapters. | Book engine, Organisation | P0 |
| Analyse structure and themes | Identify themes, motifs, repetitions, gaps and contradictions. | Intelligence, Search | P1 |
| Surface next steps | Suggest actionable next tasks based on context and progress. | Intelligence, Chat | P1 |
| Collaborate on manuscripts | Multiple users collaborate on a corpus with conflict resolution and permissions. | Security, Organisation | P2 |

## Core use cases

1. **From idea to draft:** Lisa creates a new raw text via quick
   entry, revisits it in the editor, uses AI to rewrite a stanza and
   applies the diff to create a new draft.
2. **Archive organisation:** Over a weekend, Lisa imports ten years
   of text files.  She classifies them by theme and filters out
   duplicates.  She creates a project for a forthcoming collection.
3. **Book assembly:** Lisa starts a book project, outlines five
   chapters and maps selected drafts into each chapter.  She uses
   AI suggestions to generate a provisional intro and table of
   contents.
4. **Structural analysis:** Henrik imports an author’s manuscript,
   asks the AI for a theme analysis, identifies overrepresented
   motifs and empty chapters, and writes structured feedback.
5. **Review and export:** Lisa reviews all suggestions, locks the
   final versions of each chapter, exports the book to a Markdown
   file and sends it to her editor.

## Anti‑use cases

Understanding what the Text OS is **not** helps maintain focus:

* **Task management:** it is not a generic task tracker or
  productivity planner.
* **Social publishing:** it does not host content publicly or manage
  distribution; export is the boundary.
* **Automatic content generation:** it does not write books on its
  own; it assists a human creator.
* **General data lake:** it is tuned for text content; storing
  unrelated file types (images, spreadsheets) is outside scope.

These constraints inform the design of features and help avoid
feature creep.