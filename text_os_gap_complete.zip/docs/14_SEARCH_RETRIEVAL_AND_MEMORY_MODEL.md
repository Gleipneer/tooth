# Search, Retrieval and Memory Model

Effective search and retrieval are fundamental to the Text OS.  This
document outlines the hybrid search approach (full‑text and
semantic), context assembly for AI calls and the design of
explicit memory structures like style profiles and decision logs.

## Full‑text search (FTS)

* The relational database (PostgreSQL) uses built‑in full‑text
  indexing (e.g., `tsvector`) on RawText and Draft content.  Each
  language has its own tokenizer to handle stemming and stop words.
* Search queries are parsed into terms and phrases.  The FTS engine
  returns matching passages ranked by relevance.  Results include
  document identifiers and positions for highlighting.
* Filters allow narrowing by project, date range, tag, theme, text
  type, length and status.  The API must support combining filters
  with FTS queries.

## Semantic search (vector similarity)

* Texts are broken into logical chunks (paragraphs or stanzas) when
  ingested.  Each chunk is embedded using a pre‑trained sentence
  embedding model.  Embeddings are stored in a vector index (e.g.,
  Pgvector or an external vector database) keyed by chunk ID.
* Semantic search takes a query (either user input or selected text)
  and computes its embedding.  It then retrieves the N nearest
  vectors based on cosine similarity or inner product.
* Hybrid search combines FTS and semantic scores.  For example,
  restrict semantic search to FTS results or combine scores by
  weighted sum.  The exact algorithm can be tuned via configuration.

## Retrieval for AI context assembly

AI calls require a curated set of text fragments rather than an
unbounded memory.  The retrieval pipeline:

1. **Define query:** Derived from user request.  Could be the
   highlighted passage (for rewrite) or a natural language question.
2. **Local context:** Include the current draft and its parent raw
   text by default.
3. **Manual pins:** Any texts or notes the user has pinned are
   added.
4. **Full‑text retrieval:** If the query includes keywords, perform
   FTS and retrieve top matches with high confidence.
5. **Semantic retrieval:** Compute embedding of the query.  Retrieve
   similar chunks from the vector index within the current project.
6. **Ranking and filtering:** Combine results, remove duplicates,
   exclude fragments that exceed token limits or are irrelevant by
   theme.  Sorting might use a combination of similarity and
   recency.
7. **Assemble prompt:** Provide the selected fragments with
   separators and metadata (e.g., source ID, creation date) to the
   AI prompt.  The retrieval context is logged for auditing.

Context assembly must be deterministic: given the same query and
database state, it should return the same set of fragments.  This
enables reproducibility and debugging of AI outputs.

## Memory structures

Unlike traditional chatbots, the Text OS does not rely on implicit
“long‑term memory”.  Instead, it provides explicit memory
constructs:

### Style profiles

Captures attributes of a writer’s voice or a project’s tone.  Used
for analysis and generation.  A profile stores metrics such as
average sentence length, lexical variety, sentiment distribution and
common grammatical patterns.  Profiles can be selected when
requesting rewrites (e.g., “Rewrite this passage in the style of my
2024 essay collection”).

### Decision log

Records decisions made during editing and book building.  Each entry
captures:

* **Timestamp**
* **User**
* **Subject** (e.g., “Moved chapter 3 to chapter 5”)
* **Rationale** (user notes)
* **Evidence** (links to suggestions or analyses)
* **Outcome** (applied/ignored)

The log is queryable and exportable.  It supports accountability and
helps recall why changes were made.  Decision entries may influence
future suggestions (e.g., avoid repeating a rejected theme).

### Canonical memory

Certain facts or truths about a project may be marked as canonical
(e.g., “The narrator is unreliable”, “All poems must mention the
moon”).  Canonical memory entries are user‑pinned statements that
the AI must respect.  They are stored separately from decisions
because they represent enduring constraints rather than edit
choices.

### Pinned items

Users can pin raw texts, drafts, notes or search results.  Pinned
items create a temporary context list used for AI prompts.  Pins
expire or can be removed manually.

## Avoiding “magic memory”

The system does **not** feed entire project histories to the AI.
Instead it retrieves relevant fragments on demand.  This avoids
hallucinations and respects cost constraints.  AI must never act on
information it has not been given explicitly via context assembly.

## Future considerations

* **Cross‑project search:** Allow searching across all projects with
  multi‑tenant isolation.  Requires careful permissions handling.
* **User‑controlled retrieval weights:** Users might prioritise
  recency over similarity or vice versa.  Expose controls to adjust
  weights.
* **Adaptive embedding models:** The system may support
  domain‑specific embedding models (e.g., for poetry vs. essays).
* **Vector privacy:** Embedding and vector storage must be kept
  private and not shared across users without consent.

Proper search and retrieval design is key to realising the AI
orchestration principles of deterministic context assembly and
evidence‑based suggestions.