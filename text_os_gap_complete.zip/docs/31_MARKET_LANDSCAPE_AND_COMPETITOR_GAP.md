# Market Landscape and Competitor Gap

This document maps the current landscape of tools adjacent to Text OS.
It is not a full market census. It is a **focused competitive scan**
based primarily on official product pages and documentation available at
the time of writing.

## Scope of this scan

This scan compares Text OS against five relevant categories:

1. AI-first writing editors
2. Fiction/authoring platforms
3. Book outlining / compile tools
4. Markdown knowledge tools
5. General AI workspaces

The purpose is not to prove that no similar product exists in the world.
The purpose is to identify the **closest overlaps**, then isolate the
**white space** Text OS can occupy.

## Official-source comparison set

The strongest reference points identified from official sources are:

- **Lex** — AI-powered word processor with access to multiple LLMs.
- **Sudowrite** — fiction-focused AI writing platform with drafting and
  story support.
- **Novelcrafter** — novel-writing platform with story bible / codex and
  AI assistance.
- **Scrivener** — strong outliner / corkboard / compile workflow for
  authors.
- **Ulysses** — distraction-free markup-based writing environment with
  goals and library workflows.
- **Obsidian** — local-first markdown knowledge tool with linking and a
  very large plugin ecosystem.
- **Atticus** — all-in-one writing and formatting tool for books.
- **Notion AI / Notion** — general-purpose AI workspace with document
  generation and editing in context.

## Category analysis

## 1. AI-first writing editors

### Lex

**What it clearly is good at**

- AI-native writing experience.
- LLM flexibility built directly into the editor.
- Strong appeal for users who want “best model right now” without
  constantly switching tools.

**What Text OS still does differently**

- Lex is primarily an AI word processor, not a governed corpus system.
- Text OS treats raw text as immutable source material and records
  rewrites as diffs and apply decisions.
- Text OS binds chat, retrieval, versioning and book structure into one
  domain model rather than one AI editor surface.

### Sudowrite

**What it clearly is good at**

- Fiction-first workflows.
- Draft acceleration and AI-heavy co-writing.
- Story-bible style support and plugin ecosystem around fiction.

**What Text OS still does differently**

- Sudowrite is strongly oriented toward helping users generate and draft
  fiction quickly.
- Text OS is explicitly more conservative: raw-text preservation,
  evidence-linked suggestions, explicit apply, reversible edits, and a
  broader corpus-first archive model.
- Text OS is not only for drafting forward; it is also for harvesting,
  structuring and reconciling years of fragments, notes and literary raw
  material.

## 2. Fiction/authoring platforms

### Novelcrafter

**What it clearly is good at**

- Story bible / codex model.
- Novel and worldbuilding workflows.
- AI support inside a narrative-authoring environment.

**What Text OS still does differently**

- Novelcrafter is strongly novel/story-world oriented.
- Text OS is broader and more archive-centric: poems, fragments,
  essays, reflective prose, hybrid books and long-term text archaeology.
- Text OS separates **book structure** from **text mass** more
  explicitly and treats provenance, immutability and apply logs as
  first-class governance features.

## 3. Book structure / outliner tools

### Scrivener

**What it clearly is good at**

- Binder-based manuscript organization.
- Corkboard and outliner workflows.
- Compile/export as a serious authoring toolchain.

**What Text OS still does differently**

- Scrivener is structurally powerful but not natively AI-orchestrated.
- It does not center deterministic retrieval, evidence-based chat,
  immutable raw corpus handling, or AI suggestion audit as its core
  model.
- Text OS wants Scrivener-like structural seriousness plus governed AI.

### Atticus

**What it clearly is good at**

- Writing plus formatting in one product.
- Cross-platform access.
- Book packaging and publishing-friendly output.

**What Text OS still does differently**

- Atticus is stronger on formatting/publishing workflow than deep corpus
  intelligence.
- Text OS prioritizes archive intelligence, retrieval, suggestion
  control, versioning and book synthesis from fragment mass before
  downstream formatting polish.

## 4. Markdown knowledge tools

### Ulysses

**What it clearly is good at**

- Focused writing environment.
- Markup-based editor.
- Goals, deadlines and library organization.

**What Text OS still does differently**

- Ulysses is a premium writing environment, not a governed AI writing
  operating system.
- Text OS adds corpus-level analysis, explicit AI orchestration,
  structured book assembly, and suggestion auditability.

### Obsidian

**What it clearly is good at**

- Local markdown storage.
- Links and networked thinking.
- Massive plugin surface, including AI and local-model plugins.

**What Text OS still does differently**

- Obsidian is an extensible note system rather than a cohesive,
  first-party writing workflow with a locked literary domain model.
- Users can approximate parts of Text OS in Obsidian through plugins,
  but the result is composable rather than canonical.
- Text OS offers one opinionated system for raw text intake, governed
  rewriting, retrieval-aware chat, book building and export.

## 5. General AI workspaces

### Notion AI / Notion

**What it clearly is good at**

- AI-assisted document generation and editing inside a larger workspace.
- Knowledge capture and organization.
- Agents and automations oriented to general work.

**What Text OS still does differently**

- Notion is a general workspace, not a literary operating system.
- Text OS is optimized for authorial control, versionable text lineage,
  literary structure, and archive-aware retrieval.
- Text OS refuses to treat writing as just another workspace object.

## Gap analysis

## What existing products already cover well

The market already covers these areas reasonably well:

- AI-assisted forward drafting
- distraction-free writing editors
- outlining and manuscript compile/export
- local markdown archives
- general knowledge-work AI assistance

## What appears under-covered

The following combination appears substantially under-covered:

1. **Immutable raw-text archive as first-class foundation**
2. **ChatGPT-like conversation directly anchored to text objects**
3. **Explicit apply / ignore / diff / branch discipline for AI edits**
4. **Deterministic retrieval with visible evidence for AI claims**
5. **Book engine as a real domain layer, not just headings in a doc**
6. **Fragment-first to book-first workflow for non-linear writing**
7. **Strong portability and low lock-in**
8. **Governed AI rather than maximal generative automation**

## White-space thesis for Text OS

The product opportunity is not “an AI editor.”

The white space is:

> **A governed literary operating system that turns years of raw text
> fragments into versioned drafts, retrieval-aware conversations and
> structured books without surrendering control to the model.**

That positioning differs from:

- **Lex**: AI word processor
- **Sudowrite**: fiction co-writing accelerator
- **Novelcrafter**: narrative planning + story bible platform
- **Scrivener**: structural manuscript tool
- **Obsidian**: extensible markdown thinking environment
- **Notion AI**: general workspace AI

## Closest overlap by capability cluster

| Capability cluster | Closest market analogue | Why it is close | Why it is still not the same |
| --- | --- | --- | --- |
| AI-native editing | Lex | Strong AI editor shell | lacks Text OS governance model and book-domain layer |
| Fiction drafting | Sudowrite | strong authoring AI | more co-writing oriented, less archive-governance oriented |
| Story bible / codex | Novelcrafter | structured narrative support | narrower toward novels/worldbuilding than corpus-wide literary OS |
| Outlining / compile | Scrivener | serious manuscript structure | lacks integrated retrieval-aware AI governance |
| Local markdown archive | Obsidian | strong local text ownership | plugin ecosystem, not single canonical writing OS |
| Writing + formatting | Atticus | book-oriented workflow | weaker corpus intelligence / AI governance emphasis |

## Strategic implication

Text OS should **not** try to beat incumbents at their strongest isolated
advantages.

Instead it should win on **system coherence**:

- archive discipline
- version discipline
- AI trust discipline
- book synthesis from fragments
- writer-centered context assembly
- long-term portability

## Product risk

The risk is that users may initially compare Text OS to simpler tools and
not immediately understand the difference. Therefore the product must
communicate its value through a small number of strong surfaces:

1. **Raw → Draft → Book lineage**
2. **Apply-controlled AI editing**
3. **Context-visible literary chat**
4. **Book structure from archive fragments**
5. **Reliable export / ownership**

## Honest constraint

This document is a focused comparative analysis, not a proof that no
other product anywhere offers a near-identical model. That stronger claim
would require a much broader market study. The conclusion here is an
inference from the most relevant official products examined.

## Sources consulted

Official product and help pages consulted for this comparison included:

- Lex official site and pricing pages
- Sudowrite official site and pricing pages
- Novelcrafter official site, features pages and help/changelog pages
- Scrivener official overview and tutorial pages
- Ulysses official product and help pages
- Obsidian official site and plugin directory
- Atticus official site and help/tutorial pages
- Notion official AI/product/release pages

This source set is sufficient for product-shape comparison and white-space
analysis at the current stage.
