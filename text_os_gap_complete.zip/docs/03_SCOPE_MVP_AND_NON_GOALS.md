# Scope: MVP and Non‑Goals

This document defines the minimum viable product (MVP) for the first
version of the Text OS and identifies features that are explicitly
deferred or out of scope.  The goal is to deliver a usable
foundation that proves the value of the product while establishing a
stable architecture for later expansion.

## Structure of priorities

For clarity the roadmap uses three priority classes:

- **P0 – MVP**: must be delivered in the first public release.  These
  capabilities form the core of the Text OS and should be built first.
- **P1 – Post‑MVP**: important functions that follow closely after
  release once the core is stable.  Some design hooks may be
  implemented in the MVP, but full functionality is deferred.
- **P2 – Future/Experimental**: valuable features that require
  additional research, validation or infrastructure.  They should not
  distract from delivering the MVP.

Each feature in the catalog has a priority assigned.  Changes to
priorities require an ADR or scope amendment.

## MVP scope (P0)

The MVP focuses on capturing text, organising it, editing it with a
rich editor, engaging with AI as an assistant, building simple book
structures and exporting the results.  The following capabilities
belong in P0:

### Capture and ingestion

* **Manual entry of raw text** via a clean editor or quick entry
  overlay.
* **Import of plain text and Markdown** files.  Other formats are
  deferred.  Metadata extraction should capture title, creation
  date and source path.
* **Basic language and text‑type detection** to drive routing
  decisions (e.g., classify as poem, essay fragment, journal note).

### Storage and versioning

* **Immutable raw text store** with content saved as Markdown and
  metadata persisted in the relational database.
* **Version control for drafts**: editing a text creates a draft
  record linked back to the raw text.  Each draft stores a diff from
  its parent and metadata (author, timestamp, branch).
* **Branching and diffing**: users can branch a draft, compare two
  versions side by side and revert changes.  Merging is manual.

### Organisation and navigation

* **Projects and collections**: a hierarchical tree for grouping raw
  texts, drafts, books and conversations.  Projects serve as top‑level
  containers.
* **Tagging and themes**: users may assign tags and record themes
  manually.  Tag lists are managed via the UI.
* **Book projects**: the ability to create a new book with a title
  and simple outline (part/chapter/section) and attach texts to
  outline nodes.

### Editor and text operations

* **Rich text/Markdown editing** with basic formatting (bold,
  italic, headings, lists) and code fences.  The editor must support
  diff view, inline comments and suggestions.
* **AI‑powered rewriting**: the user may select a passage and ask the
  AI to rewrite, shorten, expand or clarify it.  Suggestions are
  presented in a diff‑style preview requiring explicit apply.
* **Manual operations**: splitting or combining paragraphs, moving
  text blocks within a draft, locking sections, undo/redo.

### Chat workspace

* **Chat per project and per text**: the user can start a
  conversation tied to a project or a specific text object.  Each
  conversation records context and messages.
* **Prompted analysis and structure suggestions**: the AI can be
  asked to analyse a text, suggest structural improvements or
  identify themes.  Outputs are structured and must cite relevant
  fragments.
* **Next‑step guidance**: based on text context, the AI may propose
  a small set of next actions (e.g., “merge these two drafts”, “write
  an intro”).  The user can accept or ignore these suggestions.
* **Apply/ignore mechanisms** for AI suggestions.

### Book engine

* **Create a simple book** with title, description and basic outline
  (parts, chapters, sections).
* **Map texts to outline nodes**: assign drafts or raw texts to a
  chapter.  The system should track which texts are placed and which
  remain unassigned.
* **Generate table of contents (TOC)** based on the outline.
* **Export a book** as a single Markdown document with headings and
  inserted texts.

### Search and retrieval

* **Keyword search** across raw texts, drafts and notes using
  full‑text search (FTS) in the database.
* **Semantic search** limited to the current project: embed
  paragraphs with a vector model and return the top N similar
  fragments.  This supports context assembly for AI calls.

### Import/export/portability

* **Export of drafts and books to Markdown or plain text**.
* **Backup of the database and text files** via manual command or
  UI trigger.  The system must document the backup/restore process.

### Security and privacy

* **Local authentication**: simple user login to protect the data
  store on the server.  Multi‑user support is deferred.
* **Audit logs** of AI interactions: record model, inputs, outputs
  and cost for each call.

### Observability and quality

* **Application logging** for errors and events.
* **Basic AI evaluation**: surface metrics on suggestion acceptance
  and retrieval precision.

## Post‑MVP scope (P1)

These features extend the system once the MVP is proven:

* **Import additional formats**: docx, pdf, epub and html, with
  metadata extraction and optional OCR for scanned PDFs.
* **Audio transcription**: upload audio files and transcribe to
  text using an external speech‑to‑text service.
* **Image‑to‑text extraction**: simple OCR for images.
* **Advanced outline types**: support for scene cards and nested
  sequences, multiple alternative outline versions per book.
* **Style profiles and theme analysis**: persistent profiles of a
  writer’s style or a project’s tone; ability to compare drafts to a
  profile.
* **Decision log and canonical memory**: track decisions and
  editorial canon across projects.
* **Hybrid search across entire archive**: integrate full‑text and
  semantic search across all projects with filters on date, tags,
  length and themes.
* **Enhanced export**: create EPUB and PDF outputs with proper
  formatting and cover generation.
* **User customisable prompts**: allow users to save and reuse
  prompt templates for AI interactions.
* **Token/cost budget controls**: allow users to set monthly or
  project‑level cost limits and view usage.
* **Observability dashboards**: interactive dashboards for AI cost,
  quality metrics and usage patterns.
* **Collaborative preparation**: begin architectural preparation
  (permission model, data partitioning) for future multi‑user
  scenarios, but do not expose multi‑user UI yet.

## Future/Experimental (P2)

These capabilities depend on further research or user feedback.  They
should not be attempted until the product is mature:

* **Daily resurfacing engine** that resurfaces old texts based on
  themes or anniversaries.
* **Motif graphs and timeline visualisations** of themes across
  time.
* **Cross‑corpus style imitation** using large models fine‑tuned on
  a user’s archive.
* **Conflict‑safe collaborative editing** supporting multiple
  authors with merge conflict resolution.
* **Web clipper and email ingestion** to capture external content
  directly into the Text OS.
* **Offline‑tolerant client** that allows editing without internet
  connectivity and syncs on reconnect.
* **Pluggable provider model** where other AI providers or local
  models can be added dynamically.
* **Advanced moderation** and misuse detection using specialised
  models.

## Non‑goals

The following areas are explicitly out of scope for the foreseeable
future.  Attempting to include them would compromise the focus of
the Text OS:

* **General note‑taking for tasks unrelated to writing** (e.g., todo
  lists, calendar, project management).  The system is a writing
  environment, not a personal organiser.
* **Automatic ghost writing**: the goal is to assist, not replace
  the author.  Generative co‑writing beyond suggestions is not part
  of the system.
* **Social features**: sharing, comments and public publishing
  functions are outside of the scope.  Export is for personal use;
  separate publishing pipelines can be integrated later.
* **Multi‑modal creative generation** (images, video, music) beyond
  simple OCR or transcription.  The focus remains on written
  language.
* **Real‑time collaborative document editing**: concurrency and
  conflict resolution for multi‑user editing is deferred until P2.
* **End‑user training of models**: training custom models on the
  user’s corpus is a future research item.  The MVP uses pre‑trained
  models via an external API.

## Assumptions and trade‑offs

Several assumptions guide the MVP:

1. A single user working on a personal archive is simpler to design
   and launch quickly.  Starting with multi‑user support would
   drastically increase complexity.  A future ADR will revisit this.
2. Storing canonical text in plain files ensures long‑term
   durability, but requires a relational database for metadata and
   retrieval.  This trade‑off is accepted to avoid vendor lock‑in.
3. Implementing semantic search and basic AI rewriting in the MVP
   provides enough early value to justify the cost.  Further AI
   features will be added only after evaluating usage patterns and
   cost.

Open questions and risks related to scope are tracked in
`docs/28_RISKS_OPEN_QUESTIONS_AND_DECISION_LOG.md`.