# Documentation Index

This index provides a high‑level map of all documents in the
repository.  It describes the role of each file and suggests an
order in which to read them.  The documents are numbered for
convenience; the numbers do not imply order of execution but reflect
logical grouping.

## Table of contents

| File | Purpose | Normativity |
|---|---|---|
| `/README.md` | Overview of the repository and its purpose | Introductory |
| `/AGENTS.md` | Guidelines for future code‑generating agents | Normative |
| `/SOURCE_OF_TRUTH.md` | Defines precedence among documents and conflict resolution | Normative |
| `/docs/01_PRODUCT_VISION.md` | Describes the product vision and the problem it solves | Narrative |
| `/docs/02_DESIGN_PRINCIPLES_AND_INVARIANTS.md` | Lists non‑negotiable design principles and invariants | Normative |
| `/docs/03_SCOPE_MVP_AND_NON_GOALS.md` | Defines the minimum viable product and what is excluded | Normative |
| `/docs/04_PERSONAS_JOBS_AND_CORE_USE_CASES.md` | Describes user personas and core use cases | Normative |
| `/docs/05_FEATURE_CATALOG.md` | Catalogue of all features, priorities and acceptance criteria | Normative |
| `/docs/06_INFORMATION_ARCHITECTURE.md` | Outlines the information architecture and navigation model | Normative |
| `/docs/07_DOMAIN_MODEL.md` | Defines first‑class objects, attributes and relationships | Normative |
| `/docs/08_OBJECT_STATES_AND_LIFECYCLES.md` | Describes state machines and lifecycle transitions | Normative |
| `/docs/09_USER_FLOWS.md` | End‑to‑end user flows and scenarios | Normative |
| `/docs/10_FRONTEND_APP_SHELL_AND_NAVIGATION.md` | Specifies the UI shell and navigation structures | Normative |
| `/docs/11_EDITOR_AND_TEXT_OPERATIONS.md` | Details editor capabilities and text operations | Normative |
| `/docs/12_CHAT_WORKSPACE_AND_INTERACTION_MODEL.md` | Defines the chat workspace and interaction patterns | Normative |
| `/docs/13_BOOK_ENGINE_AND_OUTLINE_SYSTEM.md` | Defines the book engine and outline system | Normative |
| `/docs/14_SEARCH_RETRIEVAL_AND_MEMORY_MODEL.md` | Describes search, retrieval and memory architecture | Normative |
| `/docs/15_AI_ORCHESTRATION_PROMPTS_AND_STRUCTURED_OUTPUTS.md` | Specifies AI roles, prompts and output schemas | Normative |
| `/docs/16_MODEL_ROUTING_COSTS_AND_PROVIDER_POLICY.md` | Provides model selection, cost and provider policy | Normative |
| `/docs/17_BACKEND_API_CONTRACTS.md` | Defines API endpoints and request/response contracts | Normative |
| `/docs/18_DATABASE_SCHEMA_AND_STORAGE_MODEL.md` | Details database schema and storage strategy | Normative |
| `/docs/19_ASYNC_JOBS_EVENTS_AND_PIPELINES.md` | Specifies background jobs, events and pipelines | Normative |
| `/docs/20_IMPORT_CAPTURE_AND_INGESTION.md` | Describes capture and ingestion workflows | Normative |
| `/docs/21_EXPORT_PUBLISHING_AND_PORTABILITY.md` | Covers export formats and portability | Normative |
| `/docs/22_SECURITY_PRIVACY_PERMISSIONS_AND_AUDIT.md` | Defines security, privacy and audit considerations | Normative |
| `/docs/23_OBSERVABILITY_EVALUATION_AND_QUALITY.md` | Details observability and evaluation strategy | Normative |
| `/docs/24_TEST_STRATEGY_ACCEPTANCE_CRITERIA_AND_GATES.md` | Outlines test strategy and acceptance gates | Normative |
| `/docs/25_ERROR_STATES_EMPTY_STATES_AND_EDGE_CASES.md` | Enumerates error and empty states | Normative |
| `/docs/26_ROADMAP_PHASES_AND_RELEASE_PLAN.md` | Provides the phased roadmap and release plan | Normative |
| `/docs/27_IMPLEMENTATION_BUILD_ORDER.md` | Recommended build order for implementation teams | Normative |
| `/docs/28_RISKS_OPEN_QUESTIONS_AND_DECISION_LOG.md` | Risk register, open questions and decisions log | Normative |
| `/docs/29_UI_COPY_GUIDELINES_AND_CONTENT_TONE.md` | Guidelines for UI copy and content tone | Normative |
| `/docs/adr/` | Architecture Decision Records enumerating key choices | Normative |

## Recommended reading order

1. Read `README.md` and `SOURCE_OF_TRUTH.md` to understand the
   repository layout and precedence rules.
2. Study `docs/01_PRODUCT_VISION.md` to grasp the mission of the
   product.
3. Familiarise yourself with the design invariants and scope in
   `docs/02_DESIGN_PRINCIPLES_AND_INVARIANTS.md` and
   `docs/03_SCOPE_MVP_AND_NON_GOALS.md`.
4. Review the personas and core use cases in
   `docs/04_PERSONAS_JOBS_AND_CORE_USE_CASES.md`.
5. Examine the domain model, object states and lifecycles in
   `docs/07_DOMAIN_MODEL.md` and `docs/08_OBJECT_STATES_AND_LIFECYCLES.md`.
6. Consult the feature catalogue and information architecture to
   understand system capabilities and navigation.
7. Dive into detailed specifications (API contracts, database, AI
   orchestration) once you have the high‑level context.

For any decision that seems unclear, search the ADRs in
`docs/adr/` or check the open questions log.


## Addendum documents

| File | Purpose | Normativity |
|---|---|---|
| `/docs/30_UBUNTU_DEPLOYMENT_AND_OPERATIONS.md` | Canonical Ubuntu server deployment, service topology, backup and rollback runbook | Normative for self-hosted deployment |
| `/docs/31_MARKET_LANDSCAPE_AND_COMPETITOR_GAP.md` | Focused competitive scan and product white-space analysis | Supporting / strategic |
| `/docs/32_FRONTEND_INTERACTION_SPEC_CHATGPT_PARITY.md` | High-resolution interaction design for chat/editor parity | Normative for frontend behavior |
| `/docs/33_GAP_AUDIT_AGAINST_CONVERSATION.md` | Audit of package coverage vs. broader conversation | Supporting / governance |
| `/docs/34_RUNTIME_COST_AND_CAPACITY_GUARDRAILS.md` | Concrete cost, concurrency, context and degradation guardrails | Normative for runtime policy |
