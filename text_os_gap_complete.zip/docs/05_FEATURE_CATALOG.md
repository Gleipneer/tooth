# Feature Catalog

This catalog enumerates all identified features for the Text OS and
classifies them by functional domain, priority, dependencies and
acceptance criteria.  It should be used in concert with the scope
document to plan implementation work and with the domain model to
understand data requirements.

> **Note:** The catalog focuses on functional capabilities.  Non‑
> functional requirements—performance, scalability, cost, security—are
> captured in other documents.

## Table legend

| Field | Description |
| --- | --- |
| **Domain** | Functional grouping of related features. |
| **Feature** | Name of the capability. |
| **Priority** | P0 (MVP), P1 (Post‑MVP), or P2 (Future). |
| **Depends on** | Other features or architectural foundations required. |
| **Risk** | High/Medium/Low relative to complexity or uncertainty. |
| **Acceptance criteria** | Summary of conditions that must be met for the feature to be considered complete. |

## Core features

| Domain | Feature | Priority | Depends on | Risk | Acceptance criteria |
| --- | --- | --- | --- | --- | --- |
| Capture | Manual entry of raw text | P0 | Editor | Low | Users can type or paste text; text is saved as a RawText with metadata; no data loss on refresh. |
| Capture | Import plain text & Markdown | P0 | Ingestion pipeline | Low | Users can select files; system extracts metadata and creates RawText records; duplicates are flagged. |
| Capture | Basic language & type detection | P0 | NLP module | Medium | Imported text is tagged with language and classified (poem, prose, note) with >90% accuracy; errors can be corrected manually. |
| Storage | Immutable raw text store | P0 | Filesystem & database schema | Low | RawText files are stored on disk; metadata in DB; original content is never mutated. |
| Storage | Version control for drafts | P0 | Database schema, diff engine | Medium | Drafts reference parent versions; diffs are generated; branches can be created; users can view history and revert. |
| Organisation | Projects & collections | P0 | DB schema | Low | Users can create projects; assign texts, drafts, books, and conversations; hierarchical navigation is functional. |
| Organisation | Tagging & themes | P0 | Metadata model | Low | Users can assign, edit, delete tags and themes; filtering by tag works. |
| Book engine | Create simple book project | P0 | DB schema | Low | Users can input title and description; create outline with parts/chapters/sections; assign texts; TOC generates. |
| Editor | Rich text/Markdown editing | P0 | Editor component | Medium | The editor supports headings, emphasis, lists and code; diff view and comments are available; unsaved changes are warned. |
| Editor | AI‑powered rewrite operations | P0 | AI orchestration | Medium | User selects text and chooses rewrite type; model returns suggestion; user can apply or discard; applied changes persist as new version. |
| Chat | Chat per project/text | P0 | Conversation model | Low | Each chat thread stores messages and context; switching between chats preserves state; messages persist on reload. |
| Chat | Analysis & structure suggestions | P0 | AI orchestration, retrieval | High | AI returns structured analysis citing source passages; suggestions include theme identification and structural gaps; false positives are under 10%. |
| Chat | Next‑step guidance | P0 | AI orchestration | Medium | For a given context, AI proposes up to three actionable next steps with rationale; suggestions are contextually relevant. |
| Search | Keyword search (FTS) | P0 | Database indexing | Low | Users can search across texts; results return matching passages sorted by relevance; search is case‑insensitive and diacritic tolerant. |
| Search | Semantic search within project | P0 | Embedding store, retrieval module | Medium | For a query or selected text, the system returns top N semantically similar passages with similarity scores; results link back to documents. |
| Export | Export draft/book to Markdown | P0 | Export module | Low | Users can export selected drafts or books as Markdown; exported file includes headings, front matter and inserted text; metadata is not leaked. |
| Security | Local authentication | P0 | Auth module | Low | The system prompts for login; password is stored securely; data cannot be accessed without login. |
| Observability | Application logging | P0 | Logging infrastructure | Low | Errors, warnings and key events are logged; logs rotate; logs can be viewed by the admin. |
| Observability | Basic AI evaluation | P0 | AI metrics store | Medium | The system tracks AI call statistics (latency, token usage, acceptance rate); metrics are visible in a dashboard. |

## Post‑MVP features

| Domain | Feature | Priority | Depends on | Risk | Acceptance criteria |
| --- | --- | --- | --- | --- | --- |
| Capture | Import additional formats (docx, pdf, epub, html) | P1 | Ingestion pipeline, third‑party parsers | Medium | Files are parsed into RawText objects; metadata extracted; layout is reasonably preserved; unsupported elements are flagged. |
| Capture | Audio transcription | P1 | Speech‑to‑text service | Medium | Users can upload audio; text transcript created with time codes; error rate <15%; audio retained or discarded per user preference. |
| Capture | Image OCR | P1 | OCR service | Medium | Uploaded images are parsed into text; output includes location information; error rate <10%. |
| Organisation | Advanced outline types | P1 | Outline model, UI updates | Medium | Scenes/cards can be created; multiple outline variants per book; users can reorder and compare outlines. |
| Organisation | Decision log & canonical memory | P1 | Metadata model, UI | Medium | Decisions are stored with context and timestamp; canonical facts can be pinned; retrieval uses this memory. |
| Editor | Advanced AI editing (tone shift, rhythm tuning) | P1 | AI orchestration | Medium | Additional rewrite options beyond basic shorten/expand; suggestions maintain voice; diff preview is clear. |
| Chat | User‑customisable prompts | P1 | Prompt management module | Low | Users can save prompts with placeholders; prompts appear in UI; variables are filled automatically; outputs respect structure. |
| AI | Theme & motif analysis across corpus | P1 | Embedding store, analysis pipeline | High | System identifies motifs and themes over time; results are grouped; users can explore clusters; false positives <20%. |
| Search | Hybrid search across archive | P1 | Indexing and retrieval across projects | Medium | Keyword and semantic search operate over the entire corpus; filter by project, date, tags; results return quickly (<2s). |
| Export | EPUB/PDF generation | P1 | Typesetting module, external libraries | Medium | Exported files meet EPUB3/PDF/A standards; TOC links work; fonts and styling are consistent. |
| Security | Permission model groundwork | P1 | Auth module, data partitioning | High | Data structures support role‑based access; no UI yet for multiple users; tests verify isolation. |
| Observability | Cost budgets & dashboards | P1 | Billing module, metrics | Medium | Users set cost limits; system enforces token budgets; dashboards show usage per project. |

## Future features

| Domain | Feature | Priority | Depends on | Risk | Acceptance criteria |
| --- | --- | --- | --- | --- | --- |
| Capture | Web clipper / email ingestion | P2 | Browser extension, ingestion pipeline | High | User can send content from web or email to inbox; metadata captured; duplicates handled; security verified. |
| AI | Corpus‑aware style imitation | P2 | Fine‑tuning infrastructure | High | The system can generate text in a user’s style after training; user retains control; ethical guidelines met. |
| AI | Conflict‑safe collaborative editing | P2 | Real‑time sync, conflict resolution | High | Multiple users can edit concurrently; conflicts are surfaced for resolution; no data is lost. |
| UI | Timeline and motif graphs | P2 | Visualisation library | Medium | Users can view interactive graphs of theme occurrence over time; graphs are linked back to documents. |
| Operations | Offline‑tolerant client | P2 | Sync engine | High | Users can work offline; changes sync and reconcile on reconnect; conflicts are handled gracefully. |
| Governance | Moderation and misuse detection | P2 | Moderation service | High | System detects and flags abusive or malicious use of AI; logs actions; allows user appeal. |

## Using this catalog

Product management should review this catalog regularly and revise
priorities based on user feedback and technical feasibility.  Changes
should be recorded via an ADR or decision log entry.  The catalog
should remain consistent with the scope document and the roadmap.