# Object States and Lifecycles

This document describes the lifecycle of each core domain entity in the
Text OS.  State machines define allowed transitions, enforce
invariants and guide implementation of UI prompts and API
behaviours.  All state transitions must be explicitly triggered by
user actions or job completion; there are no silent state changes.

## RawText

Raw texts are immutable and therefore have a simple lifecycle:

```
┌───────────┐      ┌───────────┐
│ Imported  │──┐   │ Archived  │
└───────────┘  │   └───────────┘
               │
               │ Archive (explicit)
               ▼
           ┌───────────┐
           │  Deleted? │ (prohibited)
           └───────────┘
```

* **Imported**: When a raw text is created via typing, pasting or
  import.  Metadata and content are recorded.
* **Archived**: The user may archive a raw text to hide it from
  active lists.  Archived texts remain immutable and can be
  restored at any time.
* **Deleted**: Raw texts cannot be deleted to preserve the promise
  of immutability.

## Draft

Drafts represent editable versions and follow a richer state machine:

```
┌────────────┐    Freeze   ┌─────────────┐
│ in_progress├───────────>│  frozen     │
└──────┬─────┘             └──────┬──────┘
       │    Archive                │ Restore
       ▼                           ▼
┌────────────┐    Restore   ┌─────────────┐
│  archived  ├─────────────>│ in_progress │
└────────────┘             └─────────────┘

```

* **in_progress**: Default state when a draft is created.  The
  user can edit the content, branch, and apply suggestions.
* **frozen**: The user can freeze a draft (equivalent to locking).  A
  frozen draft cannot be edited directly.  To continue editing, the
  user must create a new version.
* **archived**: When a draft is no longer relevant (e.g., an early
  version), the user may archive it.  Archived drafts are hidden by
  default but remain accessible.  They can be restored to
  `in_progress` state if needed.

Drafts may move from `in_progress` to `frozen` multiple times and may
be archived from either state.  Frozen drafts cannot be edited or
branched; create a new draft to branch.

## BookProject

Books are containers for publication and follow these states:

```
┌───────┐     Review    ┌─────────┐    Finalise   ┌──────────┐
│ draft ├─────────────>│ in_review├─────────────>│ finalized │
└───┬───┘               └─────┬───┘               └────┬─────┘
    │    Archive               │ Archive               │ Archive
    ▼                          ▼                       ▼
┌─────────┐             ┌──────────┐            ┌───────────┐
│ archived│             │ archived │            │ archived   │
└─────────┘             └──────────┘            └───────────┘
```

* **draft**: The book is under construction.  Outline nodes can be
  edited and texts mapped.
* **in_review**: The user has signaled that the book is ready for
  holistic review (by self or another party).  Editing is limited to
  minor fixes; major structural changes should occur in the `draft`
  state.
* **finalized**: The book is considered complete.  It can still be
  exported and annotated but further structural editing requires
  creating a new version or copying to a new book project.
* **archived**: The book is no longer active.  It can be restored to
  `draft` for revisions.

## OutlineNode

Outline nodes follow a simpler state:

* **unassigned**: Node exists in outline but has no texts assigned.
  It may contain child nodes.
* **assigned**: At least one draft or raw text has been mapped to
  this node.
* **finalized**: The node’s mapping is locked; no further changes
  permitted.  Usually used for final book export.
* **archived**: Node is obsolete.  It remains for historical
  integrity but is hidden in the UI.

Node states are independent, meaning a book may contain nodes in
different states simultaneously.  Finalising a book requires all
nodes to be at least `assigned` or `finalized`.

## Conversation and Suggestion

Conversations are persistent and do not have formal states; they
remain open for reference.  Suggestions, however, have lifecycle
flags:

* **open**: A new suggestion awaiting user action.  The user may
  apply, ignore or defer.
* **applied**: The user applied the suggestion; a corresponding
  version is created if the suggestion modifies a draft.
* **ignored**: The user explicitly rejected the suggestion.
* **expired**: The suggestion is outdated (e.g., the underlying
  context changed significantly).  Expired suggestions may still be
  reviewed but cannot be applied.

## Jobs

Jobs progress through these states:

* **pending**: Created and waiting for execution.
* **running**: Currently processing.  Includes a progress meter.
* **completed**: Finished successfully with results recorded.
* **failed**: Encountered an error.  The error message is stored and
  can be reviewed; the user may retry.

Jobs cannot move backward to `pending` once started.  To repeat a
process, a new job must be created.

## State transition rules

* Only users can trigger state changes for drafts, books and outline
  nodes; AI cannot automatically change states.
* Archiving and unarchiving are explicit actions and require
  confirmation.
* Finalizing a book or node is irreversible without creating a new
  copy.  This enforces the invariant of immutability for published
  work.
* Suggestions expire automatically if their input context no longer
  matches the current state (e.g., user edited the draft).  The
  system must detect this mismatch and mark suggestions as expired.

These lifecycle definitions support UX design (e.g., disabling
editing controls on frozen drafts) and inform API validations.