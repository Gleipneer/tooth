# Guidelines for Code‑Generating Agents

This document establishes rules and expectations for future AI agents
tasked with generating code or further documentation for the Text OS
project.  The goal of these guidelines is to preserve the integrity
of the system’s design by ensuring that automated agents follow the
prescribed architecture and do not introduce contradictions or hidden
assumptions.

## Truthfulness and verification

- **Adhere to the source of truth.** Agents must consult the
documentation in this repository, especially the normative
documents listed in `SOURCE_OF_TRUTH.md`, before making any
decisions.  If information appears to be missing or ambiguous,
agents should flag it in a decision log rather than invent details.
- **Minimal change policy.** When extending or modifying the system,
agents must not alter existing invariants or principles unless
explicitly permitted by a new ADR.  Backwards‑incompatible changes
require a documented migration strategy and product owner approval.
- **Verification required.** Generated code or additional
documentation must include automated tests or review prompts that
validate behaviour against the acceptance criteria defined in
`docs/05_FEATURE_CATALOG.md` and invariants in
`docs/02_DESIGN_PRINCIPLES_AND_INVARIANTS.md`.

## Handling uncertainty

- **Identify open questions.** If a requirement is unclear or
contradictory, agents must record the issue in
`docs/28_RISKS_OPEN_QUESTIONS_AND_DECISION_LOG.md` under the
appropriate heading and request clarification.  Do not assume a
default behaviour.
- **Escalate before executing.** For operations that are irreversible
(e.g., migrating schemas, deleting data, changing the AI
provider), agents must seek explicit approval from the product
owner or governance mechanism defined in the documentation.

## Forbidden behaviours

- **Do not break invariants.** Agents must never violate the
invariants listed in `docs/02_DESIGN_PRINCIPLES_AND_INVARIANTS.md`.
  Examples include writing directly to canonical texts without a
verified apply process, discarding raw text, or silently merging
AI‑generated content into user content.
- **Do not invent functionality.** Every feature implemented must
correspond to an item in `docs/05_FEATURE_CATALOG.md` or an
approved change request.  Experimental ideas belong in a separate
proposal document.
- **Do not obscure provenance.** All AI interactions must be
auditable.  Generated text must include evidence or citation
metadata linking back to the source texts or retrieval context.

## Referencing documentation

- Agents should reference documents by their file name (e.g.,
  `docs/07_DOMAIN_MODEL.md`) when describing how a design choice is
  anchored in the specification.
- When a document leaves room for interpretation, agents should
  propose an ADR rather than silently picking an interpretation.
- The `SOURCE_OF_TRUTH.md` document defines the precedence order
  when multiple documents appear to conflict.

## Handling user trust

Agents must operate transparently: the system is designed so that
users can audit all AI activity.  When generating code that touches
user data, ensure logging and auditing hooks are in place and that
no hidden state influences behaviour.

Adhering to these guidelines ensures that the Text OS remains
deterministic, trustworthy and maintainable.
