# Source of Truth

The Text OS documentation is deliberately segmented into multiple
documents to improve navigability and maintainability.  However, this
segmentation can lead to questions about which document takes
precedence when guidance appears to conflict.  This file defines
the authoritative order of precedence and outlines the procedure for
resolving discrepancies.

## Precedence order

1. **Architecture Decision Records (ADRs)** — Documents in
   `docs/adr/` capture binding decisions made after evaluating
   alternatives.  Each ADR applies only to the context described
   within it.  When an ADR addresses a subject, its instructions
   override general design guidance.
2. **Design principles and invariants** — `docs/02_DESIGN_PRINCIPLES_AND_INVARIANTS.md` defines
   system‑wide non‑negotiable rules.  ADRs may refine these rules
   but must explicitly acknowledge any deviations.
3. **Scope and feature catalogue** — `docs/03_SCOPE_MVP_AND_NON_GOALS.md` and
   `docs/05_FEATURE_CATALOG.md` specify what must be built for
   specific releases.  These documents constrain feature
   implementation; new features require updates to the scope.
4. **Domain model and data contracts** — `docs/07_DOMAIN_MODEL.md` and
   `docs/18_DATABASE_SCHEMA_AND_STORAGE_MODEL.md` describe how data
   entities relate and must remain consistent across modules.
5. **All other documentation** — Other documents are normative for
   their domain but should defer to the higher‑level documents above
   when conflicts arise.

## Resolving conflicts

- **Local fixes via ADRs.** When a conflict or ambiguity is found,
  an Architecture Decision Record should be proposed.  The ADR
  describes the issue, the considered options, the decision, and its
  consequences.  Once accepted, it becomes part of the normative
  corpus.
- **Versioning.** Changes to normative documents must be versioned.
  The `docs/28_RISKS_OPEN_QUESTIONS_AND_DECISION_LOG.md` file
  maintains a log of decisions and their status, ensuring that
  historical context is preserved.

## Ownership

The primary owners of this documentation are the product and
architecture leads.  Updates that materially affect design or scope
require review by these stakeholders.  Minor clarifications and
corrections may be submitted via pull request with appropriate
review.
