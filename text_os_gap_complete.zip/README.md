# Text OS Documentation

Welcome to the **Text OS** documentation.  This repository contains
a comprehensive set of Markdown documents describing the design and
architecture of a personal, AI‑driven writing environment.  The system
aims to function as a *writing operating system*—a platform that
captures raw text fragments, offers chat‑based editing and analysis,
manages versions and branches, and assembles book projects through a
structured outline engine.

These documents are the **single source of truth** for the product
definition.  They specify the system’s purpose, core principles, data
structures, functional scope, user experience, backend contracts,
security posture, observability requirements and more.  No application
code is included; instead, the documentation is organized to guide a
future implementation team in building the product without guesswork.

## Repository contents

At the root of this repository you will find:

- `README.md` — this overview document.
- `AGENTS.md` — guidelines for future code‑generating agents.
- `SOURCE_OF_TRUTH.md` — explains how conflicts between documents are
  resolved and defines normative sources.
- `docs/` — the main documentation tree, with numbered files covering
  vision, principles, scope, personas, features, architecture, API
  contracts, data models, pipelines, security, testing and more.
- `docs/adr/` — Architecture Decision Records capturing key design
  choices and their rationale.

## How to read these docs

Begin with `docs/00_DOCS_INDEX.md` for a high‑level map of the
documentation.  Each file has a specific purpose: the vision document
lays out the problem and mission; design principles lock invariants;
scope defines what must be delivered in the first release; the domain
model and state machines describe the core objects and their lifecycle;
API contracts and data schemas provide detailed technical specifications;
and the ADRs document why certain architectural decisions were made.

Throughout the documents you will see references to other sections.
When conflicts arise, consult `SOURCE_OF_TRUTH.md` to determine which
document takes precedence.  The ADRs override general guidance only
when the context of an ADR explicitly addresses the issue at hand.

## Status

This repository contains **documentation only**.  No running software
exists yet.  The goal of these files is to remove ambiguity so that
engineers and AI agents can implement the system consistently.

For questions about how to interpret these docs or to report issues,
refer to the instructions in `AGENTS.md`.

## Addendum documents

- `docs/30_UBUNTU_DEPLOYMENT_AND_OPERATIONS.md` — canonical Ubuntu server deployment and runbook.
- `docs/31_MARKET_LANDSCAPE_AND_COMPETITOR_GAP.md` — market map and white-space analysis.
- `docs/32_FRONTEND_INTERACTION_SPEC_CHATGPT_PARITY.md` — high-resolution interaction and behavior spec for the editor/chat shell.
- `docs/33_GAP_AUDIT_AGAINST_CONVERSATION.md` — audit of what the package covers vs. what remained open.
- `docs/34_RUNTIME_COST_AND_CAPACITY_GUARDRAILS.md` — concrete runtime, budget, concurrency and fallback guardrails.
